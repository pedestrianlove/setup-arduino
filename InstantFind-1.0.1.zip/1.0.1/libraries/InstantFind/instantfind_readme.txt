
**** InstantData Data Link access format ****

* url --> http://data.instant-find.com:8081

## Parameters ##

* direct = device_id e.g BE7BD23E44E0A1F0  , show the data of the device ID assigned

* len    = 1~64  , data length, need to set the number same as the number defined in the InstantFind firmware

* type   = raw      : show raw data
           hex/byte : show hex array
           str      : show string
           int      : show integer
           float    : show 4 bytes float
           double   : show 8 bytes double 
           uint8    : one byte unsigned int
           int8     : one byte signed int
           uint16   : two bytes unsigned int
           int16    : two bytes signed int
           uint32   : four bytes unsigned int
           int32    : four bytes signed int
           uint64   : eight bytes unsigned int
           int64    : eight bytes signed int

* start_timestamp=2024-03-26T14:33:45  (or iso_timestamp)
                    : show data starting from the start_timestamp or iso_timestamp 
* end_timestamp=2024-03-28T14:33:45 
                    : show data ending before the end_timestamp


* data link examples 
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=raw&iso_timestamp=2024-03-26T14:33:45

http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=hex&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=byte&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=str&iso_timestamp=2024-03-26T14:33:45

http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=int&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=float&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=8&type=double&iso_timestamp=2024-03-26T14:33:45


送 uint32 4byte整數 上傳到到雲端 
用 整數顯示

http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=int&iso_timestamp=2024-03-28T22:00:00

用 16進位 字串顯示
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=hex&iso_timestamp=2024-03-28T22:00:00

用4byte float顯示
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=float&iso_timestamp=2024-03-28T22:00:00