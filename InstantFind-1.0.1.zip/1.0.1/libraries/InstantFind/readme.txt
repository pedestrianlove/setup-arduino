**** InstantData Data Link access format ****

* url --> http://data.instant-find.com:8081

## Parameters ##

* direct = device_id e.g BE7BD23E44E0A1F0  , show the data of the device ID assigned

* len    = 1~64  , data length, need to set the number same as the number defined in the InstantFind firmware

* type   = raw      : show raw data
           hex/byte : show hex array
           str      : show string
           int      : show intger
           float    : show 4 bytes float
           double   : show 8 bytes double 

* iso_timestamp=2024-03-26T14:33:45 
                    : show data from the iso_timestamp

* data link examples 
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=raw&iso_timestamp=2024-03-26T14:33:45

http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=hex&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=byte&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=str&iso_timestamp=2024-03-26T14:33:45

http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=int&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=4&type=float&iso_timestamp=2024-03-26T14:33:45
http://data.instant-find.com:8081/get?direct=BE7BD23E44E0A1F0&len=8&type=double&iso_timestamp=2024-03-26T14:33:45