//============================================================================
//
// Name        : InstantFind.h
// Author      : Brickcom
// Created on  : 2024年2月27日
// Version     : TODO
// Description : TODO
//
// Copyright 2020~2024 , Brickcom Corporation
// All Rights Reserved.
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Brickcom Corporation;
// the contents of this file may not be disclosed to third parties, copied
// or duplicated in any form, in whole or in part, without the prior
// written permission of Brickcom Corporation.
//
//============================================================================


#ifndef HARDWARE_NRF5_0_7_0_CORES_NRF5_INSTANTFIND_H_
#define HARDWARE_NRF5_0_7_0_CORES_NRF5_INSTANTFIND_H_

#include "BLEUuid.h"

#include "BLEDeviceLimits.h"
#include "BLEUtil.h"

#include "lp_timer.h"
#include "BLEPeripheral.h"
#include "utility/pa_lna.h"

#include "sha256.h"
#include "base64.h"

#include <string.h>
#include <uECC.h>


#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

#define DEFAULT_BEACON_INR		2000

#define HIGH_POWER_TX			0x7F
#define TX_HIGH_POWER			0x7F

#if defined(NRF52840)
#define MAX_TX_POWER			8
#else
#define MAX_TX_POWER			4
#endif

#define DEFAULT_BEACON_TX_POWER	MAX_TX_POWER

#define MAX_DATA_LEN			512  // 64
#define MAX_DATA_BUFFER_LEN		(MAX_DATA_LEN + (MAX_DATA_LEN / 7) +1)

#define ENCODING_DATA			true
#define NON_ENCODE_DATA			false



typedef void (*handle_update_data_t)(void);

typedef bool (*handle_update_raw_data_t)(void *data, uint16_t len);

typedef bool (*handle_update_bytes_data_t)(uint8_t data[], uint16_t len);
typedef bool (*handle_update_string_data_t)(char *data);
typedef bool (*handle_update_uint8_data_t)(uint8_t  *value);
typedef bool (*handle_update_uint16_data_t)(uint16_t *value);
typedef bool (*handle_update_uint32_data_t)(uint32_t *value);
typedef bool (*handle_update_uint64_data_t)(uint64_t *value);
typedef bool (*handle_update_float_data_t)(float *value);
typedef bool (*handle_update_double_data_t)(double *value);

typedef uint8_t (*key_arr_t)[28];


enum
{
	RAW_DATA  = 0,
	BYTES_DATA ,
	STRING_DATA,
	UINT8_DATA,
	UINT16_DATA,
	UINT32_DATA,
	UINT64_DATA,
	FLOAT_DATA,
	DOUBLE_DATA
};


typedef union
{
  uint8_t  bytes_array_data[MAX_DATA_LEN];
  uint8_t  uint8_data;
  uint16_t uint16_data;
  uint32_t uint32_data;
  uint64_t uint64_data;
  float    float_data;
  double   double_data;
} data_t;



class InstantFind : public BLEPeripheral
{
  public:
	InstantFind();
    virtual ~InstantFind(){};

    void begin();
    void end();

    //void start();
    //void stop();
    //void go_sleep();

    void set_data_type(int data_type,int default_len,int encoding);
    void set_data_len(uint16_t len);
    void set_beacon_inr(uint16_t inr_ms);
    void set_byte_send_inr(uint16_t byte_send_inr_ms);
    uint32_t data_sent_time_needed(void);

    void activate_tx_power(void);
    void set_tx_power(int tx_power);

    void start_update_data_timer_base(uint32_t inr_ms, handle_update_data_t func);


    void start_update_data_timer(uint32_t inr_ms, handle_update_raw_data_t func);

    void start_update_data_timer(uint32_t inr_ms, handle_update_bytes_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_string_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_uint8_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_uint16_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_uint32_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_uint64_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_float_data_t func);
    void start_update_data_timer(uint32_t inr_ms, handle_update_double_data_t func);
    void stop_update_data_timer();

    void process_timer_event();

    void init_data(char *str);
    void init_data(uint8_t data[],int len,int encoding);
    void init_data(uint8_t data[],int len);
    void init_data(uint8_t value);
    void init_data(uint16_t value);
    void init_data(uint32_t value);
    void init_data(uint64_t value);
    void init_data(float value);
    void init_data(double value);

    void update_data(uint8_t data[],int len);
    void update_data(uint8_t value);
    void update_data(uint16_t value);
    void update_data(uint32_t value);
    void update_data(uint64_t value);
    void update_data(float value);
    void update_data(double value);

    /* backward compatibility */
    void start_data_update_timer(uint32_t inr_ms, handle_update_bytes_data_t func)
    {
        start_update_data_timer(inr_ms, func);
    }
    void data_update(uint8_t data[],int len)
    {
        update_data(data,len);
    }


    uint8_t get_byte_data(int idx);
    void generate_data_to_send(int little_endian);
    void activate_update_data(int little_endian);
    void update_data_base(uint8_t data[], int len);


    static void _interrupt_handle_update_data_timer();
    void handle_update_data_timer();

    static void _interrupt_handle_rotate_key_timer();
    void handle_rotate_key_timer();

  public:
    static uint8_t                    g_flag_update_data_timer;

  private:

    uint8_t 						  _init;
    uint8_t 						  _started;

    // data encoding
    bool							  _encoding;

    uint16_t                          _keys_computed;
    uint16_t                          _data_len;
    uint16_t                          _key_len;
    uint16_t                          _key_idx;

    uint16_t                          _byte_send_inr;
    uint16_t                          _beacon_inr;
    int8_t							  _beacon_tx_power;
    int8_t							  _beacon_enabled_high_power;
    uint8_t                           _address[6];

    uint8_t							  _key[28];

    uint8_t                           _priv[28];
    uint8_t 						  _priv_key_len;
    uint8_t							  (*_key_arr)[28];

    uint8_t							  _new_data;
    uint16_t						  _bytes_table[MAX_DATA_LEN];

    uint8_t							  _toggle_flag_value;
    uint8_t 						  _data[MAX_DATA_LEN];
    data_t 							  _data_source;
    uint8_t                           _data_to_send[MAX_DATA_BUFFER_LEN];

    lp_timer                          _key_rotate_timer;
    lp_timer                          _update_data_timer;

    int 							  _update_data_func_data_type;
    handle_update_data_t              _update_data_func;

    uint32_t                          _update_data_timer_inr_ms;

    //handle_update_bytes_data_t         _byte_update_data_func;
    //handle_update_float_data_t        _float_update_data_func;
    //handle_update_double_data_t		  _double_update_data_func;

};


#endif /* HARDWARE_NRF5_0_7_0_CORES_NRF5_INSTANTFIND_H_ */
