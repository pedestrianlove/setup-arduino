//============================================================================
//
// Name        : InstantFind.cpp
// Author      : Brickcom
// Created on  : 2024年2月27日
// Version     : TODO
// Description : TODO
//
// Copyright 2020~2024 , Brickcom Corporation, all Rights Reserved.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
//============================================================================

#include "InstantFind.h"

#if !defined(RELEASE)
char *g_instantfind_banner[] =
		{
				"  _____                 _                     _     ______   _               _ \n",
				" |_   _|               | |                   | |   |  ____| (_)             | |\n",
				"   | |    _ __    ___  | |_    __ _   _ __   | |_  | |__     _   _ __     __| |\n",
				"   | |   | '_ \\  / __| | __|  / _` | | '_ \\  | __| |  __|   | | | '_ \\   / _` |\n",
				"  _| |_  | | | | \\__ \\ | |_  | (_| | | | | | | |_  | |      | | | | | | | (_| |\n",
				" |_____| |_| |_| |___/  \\__|  \\__,_| |_| |_|  \\__| |_|      |_| |_| |_|  \\__,_|\n",
				"\n",
				"  _____               _______                                                  \n",
				" |  __ \\      /\\     |__   __|     /\\                                          \n",
				" | |  | |    /  \\       | |       /  \\                                         \n",
				" | |  | |   / /\\ \\      | |      / /\\ \\                                        \n",
				" | |__| |  / ____ \\     | |     / ____ \\                                       \n",
				" |_____/  /_/    \\_\\    |_|    /_/    \\_\\                                      \n",
				"\n",
				NULL };

const char g_http_data_fmt[128] =
		"http://data.instant-find.com:8081/get?direct=%s&len=%d&type=%s";

const char g_http_data_fmt2[128] =
		"http://data.instant-find.com:8080/get?mac=%s";
#endif

/*
 * raw, byte(hex), string, int, float, double
 */

const char *DATA_TYPE_STR[] =
{ "raw", "byte", "str", "int", "int", "int", "int", "float", "double" };

#define TO_UPPER(x) 			( ((x)>='a') && ((x)<='f') ? (x)-'a'+'A' : (x))

#define BASE_KEY_LENGTH			28
#define LITTLE_ENDIAN 			true
#define NOT_LITTLE_ENDIAN		false
#define MINIMUM_INR				20
#define MAXIMUM_INR				10240

const char BASE_KEY_STR[] =
		"FFFFFFFF00000000FFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551";
static uint8_t _g_adv_template[] =
{ 0x4c, 0x00, 0x12, 0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00 };

#if 0
template <class T> T little_to_big_endian(T data)
{
	T value;
	uint8_t *src,*dest;
	int i,j;
	src=(uint8_t *)&data;
	dest=(uint8_t *)&value;
	for (i=0,j=sizeof(T)-1;i<sizeof(T);i++,j--)
		dest[i]=src[j];
	return value;
}
#endif

uint8_t hex(char c)
{
	uint8_t ret;
	c = TO_UPPER(c);
	if (c >= 'A' && c <= 'F')
		ret = c - 'A' + 10;
	else
		ret = c - '0';
	return ret;
}

void read_key_from_str(const char *str, uint8_t *key)
{
	int i, j;
	for (i = 0; i < strlen(str); i += 2, j++)
		key[j] = (hex(str[i]) << 4) + hex(str[i + 1]);
}

int is_valid_pub_key(uint8_t *key, int key_len)
{
	int i, len, ret = 1;
	BYTE sha256_buf[SHA256_BLOCK_SIZE];
	BYTE base_str[128];
	SHA256_CTX ctx;

	memset(base_str, 0, 128);
	memset(sha256_buf, 0, SHA256_BLOCK_SIZE);

	sha256_init(&ctx);
	sha256_update(&ctx, key, key_len);
	sha256_final(&ctx, sha256_buf);
	len = base64_encode(sha256_buf, base_str, SHA256_BLOCK_SIZE, 1);

	for (i = 0; i < 7; i++)
	{
		if (base_str[i] == '/')
		{
			ret = 0;
			break;
		}
	}

	if (ret == 0)
		BRK_COLOR_LOG_INFO(BOLD_RED_PRINT, "Base64 len:%d %s\n", len, base_str);
	else
		BRK_COLOR_LOG_INFO(BOLD_GREEN_PRINT, "Base64 len:%d %s\n", len,
				base_str);

	return ret;
}

void compute_key(uint8_t *compu_key, uint8_t *input)
{
	int n;
	const struct uECC_Curve_t *curve = uECC_secp224r1();
	uint8_t tmp[128];
	n = uECC_compute_public_key(input, tmp, curve);
	uECC_compress(tmp, compu_key, curve);
}

int check_key_valid(uint8_t *pub_key_compressed)
{
	uint8_t with_sign_byte[BASE_KEY_LENGTH + 1];
	uint8_t pub_key_uncompressed[128];
	const struct uECC_Curve_t *curve = uECC_secp224r1();
	with_sign_byte[0] = 0x02;
	memcpy(&with_sign_byte[1], pub_key_compressed, BASE_KEY_LENGTH);
	uECC_decompress(with_sign_byte, pub_key_uncompressed, curve);
	if (!uECC_valid_public_key(pub_key_uncompressed, curve))
		return 0;
	return 1;
}

int g_instantfind_init = 0;

static InstantFind *_g_if = NULL;

#define HANDLE_TIMER_EVENT_IN_IRQ		0
#define HANDLE_TIMER_EVENT_IN_LOOP		1
#define TIMER_EVENT_TIRGGERED			0x80

/* handle timer data flag */
uint8_t InstantFind::g_flag_update_data_timer = HANDLE_TIMER_EVENT_IN_LOOP;

InstantFind::InstantFind() :
		_started(0), _key_arr(NULL), _init(0), _update_data_func(NULL), _update_data_func_data_type(
				RAW_DATA), _encoding(true),
		//_byte_update_data_func(NULL),
		//_float_update_data_func(NULL),
		//_double_update_data_func(NULL),
		_toggle_flag_value(0), _key_idx(0), _key_len(0), _data_len(1), _byte_send_inr(
				0), _beacon_inr(DEFAULT_BEACON_INR), _beacon_tx_power(
				DEFAULT_BEACON_TX_POWER)
{
	int i = 0;
	uint8_t priv[BASE_KEY_LENGTH];
	uint8_t pub[29];

	read_key_from_str(BASE_KEY_STR, _priv);
	memcpy(_priv, (void*) &NRF_FICR->DEVICEADDR[0], 8);

#if 0
	nrfjprog --memrd 0x100000a4 --w 8 --n 8
#endif

#if 0
	//_priv[0]++;
	//_priv[7]++;
	_key_arr = NULL;
	_key_arr = (key_arr_t) malloc(_data_len*28);
	memcpy(priv,_priv,28);
	while(1)
	{
		compute_key(pub,priv);
		memcpy(_key_arr[0], &pub[1], 28);
		if (is_valid_pub_key(&pub[1],28)) break;
		priv[27]++;
	}
#endif

	//memset(_bytes_table,0,sizeof(uint16_t)*MAX_DATA_LEN);
	//_bytes_table[0]=0;
	memset(_data, 0, sizeof(uint8_t) * MAX_DATA_BUFFER_LEN);
	_g_if = this;
}

#define BYPASS_DISABLED 	LOW
#define BYPASS_ENABLED 	    HIGH
void InstantFind::activate_tx_power(void)
{
#if defined(PIN_FEM_TX_EN)

	if (_beacon_tx_power == HIGH_POWER_TX)
	{
		pinMode(PIN_FEM_BYPASS, OUTPUT);
		pinMode(PIN_FEM_TX_EN, OUTPUT);
		pinMode(PIN_FEM_RX_EN, OUTPUT);
		this->setTxPower(0);

		digitalWrite(PIN_FEM_BYPASS, BYPASS_DISABLED);
		digitalWrite(PIN_FEM_TX_EN, HIGH);

		pa_lna_init(g_ADigitalPinMap[PIN_FEM_TX_EN],
				g_ADigitalPinMap[PIN_FEM_RX_EN]);
		//digitalWrite(PIN_FEM_TX_EN,HIGH);

	}
	else
	{
		/* bypass FEM */
		sd_ble_opt_set(BLE_COMMON_OPT_PA_LNA, NULL);

		digitalWrite(PIN_FEM_BYPASS, BYPASS_ENABLED);
		digitalWrite(PIN_FEM_TX_EN, LOW);
		digitalWrite(PIN_FEM_RX_EN, LOW);
		this->setTxPower(_beacon_tx_power);
	}
#else
	this->setTxPower(_beacon_tx_power);
#endif
}

void InstantFind::set_tx_power(int tx_power)
{
	if (tx_power == _beacon_tx_power)
		return;
	_beacon_tx_power = tx_power;

#if 1 // 2024/4/1 add

	this->setTxPower(_beacon_tx_power);
	return;
#endif

#if defined(PIN_FEM_TX_EN)
#else
	if (tx_power>=MAX_TX_POWER)
		_beacon_tx_power=MAX_TX_POWER;
#endif
	if (_started)
	{
		sd_ble_gap_adv_stop();
		activate_tx_power();
		startAdvertising();
	}
}

void InstantFind::set_beacon_inr(uint16_t inr_ms)
{
	_beacon_inr = inr_ms;
}

void InstantFind::set_byte_send_inr(uint16_t byte_send_inr_ms)
{
	_byte_send_inr = byte_send_inr_ms;
}

void InstantFind::set_data_type(int data_type, int default_len = 0,
		int encoding = true)
{
	int len;

	_encoding = encoding;

	if (data_type == FLOAT_DATA)
		default_len = sizeof(float);
	else if (data_type == DOUBLE_DATA)
		default_len = sizeof(double);
	else if (data_type == STRING_DATA)
		;
	else if (data_type == BYTES_DATA)
		;
	else
		return;

	if (default_len == 0)
		return;
	_update_data_func_data_type = data_type;
	set_data_len(default_len);
}

/*
 * time(ms) for complete all the bytes to send
 */
uint32_t InstantFind::data_sent_time_needed(void)
{
	if (_data_len > 0)
	{
		if (_byte_send_inr == 0)
			return _beacon_inr;
		else
			return _byte_send_inr * _beacon_inr;
	}
	else
		return _beacon_inr;
}

/*
 *   # data byte  7 --> extra 1, total len_int 7+1
 *   # data byte  8 --> extra 2, total len_int 8+2
 *   # data byte 14 --> extra 2, total len_int 14+2
 *   # data byte 16 --> extra 3, total len_int 16+3
 *     extra_byte_len = 0
 *     if (len_int>1):
 *          extra_byte_len = (len_int // 7)
 *          if (len_int % 7 > 0):
 *              extra_byte_len = extra_byte_len + 1
 *              len_int = extra_byte_len + len_int
 */
void InstantFind::set_data_len(uint16_t len)
{
#if 1
	int i, j, total_len;
	uint8_t pub[29];
	uint8_t priv[BASE_KEY_LENGTH];
	uint8_t *p, *q;

	total_len = len;

	if (_encoding)
	{
		if (len >= 2)
			total_len = len + len / 7 + (len % 7 ? 1 : 0);
	}

	if ((total_len <= _keys_computed))
	{
		_data_len = len;
		_key_len = total_len;
		return;
	}

	if (_key_arr)
		free(_key_arr);

	_key_arr = (key_arr_t) malloc(total_len * BASE_KEY_LENGTH);

	if ((total_len == 1) && (NRF_UICR->CUSTOMER[7] == 0x42524943))
	{
		p = _key_arr[0];
		for (j = i = 0; i < 7; i++, j += 4)
		{
			q = (uint8_t*) &NRF_UICR->CUSTOMER[i];
			p[j] = q[3];
			p[j + 1] = q[2];
			p[j + 2] = q[1];
			p[j + 3] = q[0];
		}

		for (i = 0; i < BASE_KEY_LENGTH; i++)
			BRK_LOG_INFO("%02x", p[i]);
		BRK_LOG_INFO("\n");

		/* match server side MAC calculation */
		_priv[0] = p[5] | 0xC0;
		_priv[1] = p[4];
		_priv[2] = p[3];
		_priv[3] = p[2];
		_priv[4] = p[1];
		_priv[5] = p[0];
		_priv_key_len = 6;
	}
	else
	{
		read_key_from_str(BASE_KEY_STR, _priv);
		_priv_key_len = 8;
		memcpy(_priv, (void*) &NRF_FICR->DEVICEADDR[0], 8);

		// TODO: assert if allocate failed.
		memcpy(priv, _priv, BASE_KEY_LENGTH);
		//for (i=0;i<len+1;i++)
		i = 0;
		while (1)
		{
			compute_key(pub, priv);
			memcpy(_key_arr[i], &pub[1], BASE_KEY_LENGTH);
			priv[27]++;
			if (is_valid_pub_key(&pub[1], BASE_KEY_LENGTH))
			{
				i++;
				if (i >= total_len)
					break;
			}
		}
	}
	_keys_computed = total_len;
	_key_len = total_len;
	_data_len = len;
	if (_init > 1)
		_init = 1;

#else
    int i,idx;
	uint8_t p[BASE_KEY_LENGTH];

	if (len<2) return;

	memcpy(p,_key,28);
    for(idx=1,i=1;i<MAX_DATA_LEN*3;i++)
    {
    	p[5]++;
    	if (p[5]==0)
    		p[4]++;
    	if (check_key_valid(p))
    	{
    		_bytes_table[idx++]=i;
    		//Serial.println(i);
    	}
    	if (idx>len) break;
    }
    _data_len = len+1;

    if (_init>1)
    	_init = 1;
#endif
}
/*
 *  _toggle_flag_value 0x80 or 0x00, when changed the data, the value is toggled.
 *
 *  multiple data format for transfer
 *  data format change -->  original data [xzzzzzzz yzzzzzzz] to data_to_send [tzzzzzzz tzzzzzzz t00000xy]
 *
 *  little_endian: if the data is little endian, transform it to be the big endian.
 *  all the data sent out is big endian
 */
void InstantFind::generate_data_to_send(int little_endian)
{
	int i, j, m, n, d;
	uint8_t value = 0;
	uint8_t data = 0;

	if ((!_encoding) || (_data_len <= 1))
	{
		//_data_to_send[0] = _data[0];
		memcpy(_data_to_send,_data,_data_len);
		return;
	}

	m = little_endian ? _data_len - 1 : 0;
	d = little_endian ? -1 : 1;
	n = _data_len;
	for (data = 0, i = j = 0; i < _data_len; i++)
	{
		_data_to_send[i] = _toggle_flag_value | (_data[m] & 0x7F);
		data = (data << 1) + (_data[m] & 0x80 ? 1 : 0);
		m = m + d;
		j++;
		if (j == 7)
		{
			_data_to_send[n] = _toggle_flag_value + data;
			j = 0;
			n++;
			data = 0;
		}
	}
	if (j > 0)
		_data_to_send[n] = _toggle_flag_value + data;
}

void InstantFind::activate_update_data(int little_endian)
{

	generate_data_to_send(little_endian);

#if 0
	if (len > MAX_DATA_LEN)
		len = MAX_DATA_LEN;

	if (len == 1)
		memcpy(_data, data, len);
	else
	{
		if (memcmp(&_data[1], data, len) != 0)
		{
			memcpy(&_data[1], data, len);
			_data[0]++; //multuple bytes data, data[0] is the data flag byte..
			_new_data = !_new_data;
		}
	}

	_toggle_flag_value = (_toggle_flag_value ? 0: 0x80);
#endif

	// request to restart the data send after the data update.
	_key_idx = 0;
	if (_started)
	{
		end();
		begin();
	}
}

void InstantFind::init_data(char *str)
{
	int len = strlen(str);
	set_data_len(len);
	update_data((uint8_t*) str, len);
	_update_data_func_data_type = STRING_DATA;
}

void InstantFind::init_data(uint8_t data[], int len)
{
	set_data_len(len);
	update_data((uint8_t*) data, len);
	//_encoding = encoding;
	_update_data_func_data_type = BYTES_DATA;
}


void InstantFind::init_data(uint8_t data[], int len, int encoding = true)
{
	set_data_len(len);
	update_data((uint8_t*) data, len);
	_encoding = encoding;
	if (_encoding)
		 _update_data_func_data_type = BYTES_DATA;
	else
		 _update_data_func_data_type = RAW_DATA;
}

void InstantFind::init_data(uint8_t value)
{
	set_data_len(1);
	update_data(value);
	_update_data_func_data_type = UINT8_DATA;

}
void InstantFind::init_data(uint16_t value)
{
	set_data_len(2);
	update_data(value);
	_update_data_func_data_type = UINT16_DATA;
}
void InstantFind::init_data(uint32_t value)
{
	set_data_len(4);
	update_data(value);
	_update_data_func_data_type = UINT32_DATA;
}
void InstantFind::init_data(uint64_t value)
{
	set_data_len(8);
	update_data(value);
	_update_data_func_data_type = UINT64_DATA;
}
void InstantFind::init_data(float value)
{
	set_data_len(4);
	update_data(value);
	_update_data_func_data_type = FLOAT_DATA;

}
void InstantFind::init_data(double value)
{
	set_data_len(8);
	update_data(value);
	_update_data_func_data_type = DOUBLE_DATA;
}

void InstantFind::update_data_base(uint8_t data[], int len)
{
	if (len > MAX_DATA_LEN)
		len = MAX_DATA_LEN;
	if (memcmp(_data, data, len) != 0)
		_toggle_flag_value = (_toggle_flag_value ? 0 : 0x80);
	memset(_data, 0, MAX_DATA_LEN);
	memcpy(_data, data, len);
}

void InstantFind::update_data(uint8_t data[], int len)
{
	update_data_base(data, len);

#if 0
	if (len == 1)
		memcpy(_data, data, len);
	else
	{
		if (memcmp(_data, data, len) != 0)
		{
			memcpy(_data, data, len);
			_new_data = !_new_data;
		}
	}
#endif

	// request to restart the data send after the data update.
	activate_update_data(NOT_LITTLE_ENDIAN);

}

void InstantFind::update_data(uint8_t value)
{
	update_data_base((uint8_t*) &value, sizeof(uint8_t));
	activate_update_data(NOT_LITTLE_ENDIAN);
}

void InstantFind::update_data(uint16_t value)
{
	update_data_base((uint8_t*) &value, sizeof(uint16_t));
	activate_update_data(LITTLE_ENDIAN);
}

void InstantFind::update_data(uint32_t value)
{
	update_data_base((uint8_t*) &value, sizeof(uint32_t));
	activate_update_data(LITTLE_ENDIAN);
}

void InstantFind::update_data(uint64_t value)
{
	update_data_base((uint8_t*) &value, sizeof(uint64_t));
	activate_update_data(LITTLE_ENDIAN);
}

void InstantFind::update_data(float value)
{
	update_data_base((uint8_t*) &value, sizeof(float));
	activate_update_data(LITTLE_ENDIAN);
}

void InstantFind::update_data(double value)
{
	update_data_base((uint8_t*) &value, sizeof(double));
	activate_update_data(LITTLE_ENDIAN);
}

void InstantFind::stop_update_data_timer()
{
	_update_data_func = NULL;
	_update_data_timer.stop();
}




void InstantFind::start_update_data_timer_base(uint32_t inr_ms,
		handle_update_data_t func)
{
	_update_data_func = (handle_update_data_t) func;

	/* new add 2024-6-6 */
	_update_data_timer_inr_ms = inr_ms;

	_update_data_timer.startTimer(inr_ms, _interrupt_handle_update_data_timer);
}

#if 0
template <class T> void InstantFind::start_update_data_timer(uint32_t inr_ms, T func)
{
	_update_data_func_data_type = BYTES_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}
#endif

/*
 * raw data only
 */
void InstantFind::start_update_data_timer(uint32_t inr_ms, handle_update_raw_data_t func)
{
	_update_data_func_data_type = RAW_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_string_data_t func)
{
	_update_data_func_data_type = STRING_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_bytes_data_t func)
{
	_update_data_func_data_type = BYTES_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_uint8_data_t func)
{
	_update_data_func_data_type = UINT8_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_uint16_data_t func)
{
	_update_data_func_data_type = UINT16_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_uint32_data_t func)
{
	_update_data_func_data_type = UINT32_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_uint64_data_t func)
{
	_update_data_func_data_type = UINT64_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_float_data_t func)
{
	_update_data_func_data_type = FLOAT_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}

void InstantFind::start_update_data_timer(uint32_t inr_ms,
		handle_update_double_data_t func)
{
	_update_data_func_data_type = DOUBLE_DATA;
	start_update_data_timer_base(inr_ms, (handle_update_data_t) func);
}


void InstantFind::process_timer_event()
{
	if (g_flag_update_data_timer & TIMER_EVENT_TIRGGERED)
	{
		handle_update_data_timer();
		g_flag_update_data_timer &= (~TIMER_EVENT_TIRGGERED);
	}
	g_flag_update_data_timer |= HANDLE_TIMER_EVENT_IN_LOOP;
}

void InstantFind::_interrupt_handle_update_data_timer()
{
	if (_g_if)
	{
		if (_g_if->g_flag_update_data_timer & HANDLE_TIMER_EVENT_IN_LOOP)
			_g_if->g_flag_update_data_timer |= TIMER_EVENT_TIRGGERED;
		else
			_g_if->handle_update_data_timer();
	}
}

void InstantFind::handle_update_data_timer()
{
	bool ret = false;
	uint8_t *data_ptr = _data;
	int len = _data_len;
	int little_endian = NOT_LITTLE_ENDIAN;

	if (_update_data_func == NULL)
		return;

#if 0
	if (_data_len == 1)
	{
		data_ptr = &_data[0];
		len = 1;
	}
#endif

	if (_update_data_func_data_type == BYTES_DATA)
		ret = (*(handle_update_bytes_data_t) _update_data_func)(data_ptr, len);

	else if (_update_data_func_data_type == STRING_DATA)
		ret = (*(handle_update_string_data_t) _update_data_func)(
				(char*) data_ptr);

	else if (_update_data_func_data_type == UINT8_DATA)
		ret = (*(handle_update_uint8_data_t) _update_data_func)(
				(uint8_t*) data_ptr);
	else if (_update_data_func_data_type == UINT16_DATA)
		ret = (*(handle_update_uint16_data_t) _update_data_func)(
				(uint16_t*) data_ptr);
	else if (_update_data_func_data_type == UINT32_DATA)
		ret = (*(handle_update_uint32_data_t) _update_data_func)(
				(uint32_t*) data_ptr);
	else if (_update_data_func_data_type == UINT64_DATA)
		ret = (*(handle_update_uint64_data_t) _update_data_func)(
				(uint64_t*) data_ptr);
	else if (_update_data_func_data_type == FLOAT_DATA)
		ret = (*(handle_update_float_data_t) _update_data_func)(
				(float*) data_ptr);
	else if (_update_data_func_data_type == DOUBLE_DATA)
		ret = (*(handle_update_double_data_t) _update_data_func)(
				(double*) data_ptr);

	if (_update_data_func_data_type > UINT16_DATA)
		little_endian = LITTLE_ENDIAN;

	// if data is changed, activate the data change and update it...
	if (ret)
	{
		_toggle_flag_value = (_toggle_flag_value ? 0 : 0x80);
		activate_update_data(little_endian);
	}

}

#if 0
void InstantFind::handle_update_data_timer()
{
	bool ret = false;
	uint8_t temp[MAX_DATA_LEN+2];
	uint8_t *data_ptr = &_data[1];
	int len = _data_len;

	if (_update_data_func == NULL)
		return;
	if (_data_len == 1)
	{
		data_ptr = &_data[0];
		len = 1;
	}

	if (_update_data_func_data_type == BYTES_DATA)
		ret = (*(handle_update_bytes_data_t) _update_data_func)(data_ptr, len);
	else if (_update_data_func_data_type == FLOAT_DATA)
	{
		if (_data_len >= sizeof(float))
			ret = (*(handle_update_float_data_t) _update_data_func)(
					(float*) data_ptr);
	}
	else if (_update_data_func_data_type == DOUBLE_DATA)
	{
		if (_data_len >= sizeof(double))
			ret = (*(handle_update_double_data_t) _update_data_func)(
					(double*) data_ptr);
	}

	// update the data[0], data index if the data_len>1
	if (ret && (_data_len > 1))
	{
		_data[0]++;
		_new_data = !_new_data;
	}

	if (ret && _started)
	{
		_key_idx = 0;
		end();
		begin();
	}
}
#endif

void InstantFind::_interrupt_handle_rotate_key_timer()
{
	//Serial.println("*");
	if (_g_if)
		_g_if->handle_rotate_key_timer();
}

void InstantFind::handle_rotate_key_timer()
{
	end();
	_key_idx++;
	_key_idx %= _key_len;
	begin();

}

uint8_t InstantFind::get_byte_data(int idx)
{
#if 1
	//return _data[idx];
	return _data_to_send[idx];
#else
	int i;
	uint8_t value=0;
	uint8_t data=0;
	if (_data_len==0)
		return _data[0];

	/* multiple data handling */
	value = (_new_data? 0x80:0x00);
	if (idx==0)
	{
		for (i=1;i<=_data_len;i++)
           data = (data << 1) + (_data[i] & 0x80? 1:0);
		value += data;
	}
	else
	{
		/* keep 7 bits only */
		value = value | (_data[idx] & 0x7F);
	}

	return value;

#endif
}

void InstantFind::begin()
{
	uint16_t u, v;
	uint8_t p[BASE_KEY_LENGTH];
	int i;

#if 1

#if 0
	BYTE buf[SHA256_BLOCK_SIZE];
	BYTE ret[256];
	int len;
	SHA256_CTX ctx;
	sha256_init(&ctx);
    sha256_update(&ctx, _key_arr[_key_idx], 28);
	sha256_final(&ctx, buf);

	len = base64_encode(buf, ret, 32 , 1);
	BRK_COLOR_LOG_INFO(BOLD_GREEN_PRINT,"Base64 len:%d %s\n", len,ret);
#endif

	end();
	set_data_len(_data_len);

	/* select the new key */
	memcpy(p, _key_arr[_key_idx], BASE_KEY_LENGTH);

#else
	/* select the new key */
	memcpy(p,_key,28);
	v = p[5] + _bytes_table[_key_idx];
	p[5] = (v % 256);
	p[4] += (v / 256);
#endif

	_address[5] = p[0] | 0xC0;
	_address[4] = p[1];
	_address[3] = p[2];
	_address[2] = p[3];
	_address[1] = p[4];
	_address[0] = p[5];
	this->setDevAddress(BLE_GAP_ADDR_TYPE_RANDOM_STATIC, _address);

	_g_adv_template[4] = get_byte_data(_key_idx);
	memcpy(&_g_adv_template[5], &p[6], 22);
	_g_adv_template[27] = p[0] >> 6;
	this->setManufacturerData(_g_adv_template, BASE_KEY_LENGTH + 1);

	this->setConnectable(false);
	this->setAdvertisingInterval(_beacon_inr);

	BLEPeripheral::begin();

	//activate_tx_power();

#if !defined(RELEASE)

	char str[255];
	char mac[32];
	//char *q = (char *) &NRF_FICR->DEVICEADDR[0];
	char *q = (char*) _priv;

	if (!_init)
	{
		while (1)
		{
			if (g_instantfind_banner[i] == NULL)
				break;
			BRK_COLOR_LOG_INFO(BOLD_CYAN_PRINT, "%s", g_instantfind_banner[i]);
			//Serial.printf("%s",g_instantfind_banner[i]);
			i++;
		}
		_init = 1;
	}

	if (_init < 2)
	{

		char *p = (char*) &NRF_FICR->DEVICEADDR[0];
		for (i = 0; i < 8; i++)
		{
			BRK_COLOR_LOG_INFO(BOLD_GREEN_PRINT, "%02X ", *p);
			p++;
		}
		BRK_COLOR_LOG_INFO(BOLD_YELLOW_PRINT, "\r\n");

		memset(mac, 0, 32);

		for (i = 0; i < _priv_key_len; i++)
			sprintf(&mac[i << 1], "%02X", q[i]);
		if (_priv_key_len == 6)
			sprintf(str, g_http_data_fmt2, mac);
		else
			sprintf(str, g_http_data_fmt, mac, _data_len,
					DATA_TYPE_STR[_update_data_func_data_type]);

		BRK_COLOR_LOG_INFO(BOLD_YELLOW_PRINT, "%s\n", str);

		memset(mac, 0, 32);
		for (i = 0; i < 6; i++)
			sprintf(&mac[i << 1], "%02X", _address[5 - i]);
		BRK_COLOR_LOG_INFO(BOLD_GREEN_PRINT, "FindMy Beacon:%s\n\n", mac);
		_init = 2;
	}

	//Serial.println(_data_len);
	//Serial.println(_beacon_inr/_data_len);
#endif

	uint8_t mask = 0x80;
	uint8_t data = get_byte_data(_key_idx);
	BRK_COLOR_LOG_INFO(BOLD_PURPLE_PRINT, "Key index:%d value:%02X ", _key_idx,
			data);
	for (i = 0; i < 8; i++)
	{
		BRK_COLOR_LOG_INFO(BOLD_PURPLE_PRINT, "%d", data & mask ? 1 : 0);
		mask >>= 1;
	}
	BRK_COLOR_LOG_INFO(BOLD_PURPLE_PRINT, "\r\n");

	if (_data_len > 1)
	{
		// repeat twice per byte
		//_byte_send_inr = _beacon_inr * 50 + (_beacon_inr >> 1);
		//_key_rotate_timer.startTimer(_byte_send_inr,
		//		_interrupt_handle_rotate_key_timer);

		if (_byte_send_inr == 0)
		{
			_byte_send_inr = _beacon_inr / _key_len;
			if (_byte_send_inr <= MINIMUM_INR)
				_byte_send_inr = MINIMUM_INR;
		}

		_key_rotate_timer.startTimer(_byte_send_inr,
				_interrupt_handle_rotate_key_timer);
	}


	_started = 1;
}


void InstantFind::end()
{
	_key_rotate_timer.stop();

	sd_ble_gap_adv_stop();

	BLEPeripheral::end();
	_started = 0;
}

#if 0
void InstantFind::start()
{

	_address[5] = _key[0] | 0xC0;
	_address[4] = _key[1];
	_address[3] = _key[2];
	_address[2] = _key[3];
	_address[1] = _key[4];
	_address[0] = _key[5];
	this->setDevAddress(BLE_GAP_ADDR_TYPE_RANDOM_STATIC, _address);

	memcpy(&_g_adv_template[5], &_key[6], 22);
	_g_adv_template[27] = _key[0] >> 6;
	this->setManufacturerData(_g_adv_template, 29);

	this->setConnectable(false);
	this->setAdvertisingInterval(_beacon_inr);
	this->setTxPower(_beacon_tx_power);
	this->begin();

}

void InstantFind::stop()
{
	this->end();
}


void InstantFind::go_sleep()
{
	//sd_power_dcdc_mode_set(NRF_POWER_DCDC_ENABLE);
	//sd_power_mode_set(NRF_POWER_MODE_LOWPWR);
	::sleep();
}
#endif
