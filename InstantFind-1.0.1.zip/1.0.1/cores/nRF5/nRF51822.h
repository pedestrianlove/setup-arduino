//============================================================================
//
// Name        : nRF51822.h
// Author      : Brickcom
// Created on  : 2024-05-19
// Version     : TODO
// Description : TODO
//
// Copyright 2020~2024 , Brickcom Corporation
// All Rights Reserved.
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Brickcom Corporation;
// the contents of this file may not be disclosed to third parties, copied
// or duplicated in any form, in whole or in part, without the prior
// written permission of Brickcom Corporation.
//
//============================================================================


#ifndef INSTANTFIND_HARDWARE_INSTANTFIND_1_0_0_CORES_NRF5_NRF51822_H_
#define INSTANTFIND_HARDWARE_INSTANTFIND_1_0_0_CORES_NRF5_NRF51822_H_

#if (NRF_SD_BLE_API_VERSION==2)
#include "nRF51822_sd_2.h"
#endif

#if (NRF_SD_BLE_API_VERSION>=5)
#include "nRF51822_sd_5.h"
#endif



#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

#endif /* INSTANTFIND_HARDWARE_INSTANTFIND_1_0_0_CORES_NRF5_NRF51822_H_ */
