#include <stdint.h>
#include <string.h>

#include "pa_lna.h"
#include "ble.h"
#include "app_error.h"
#include "nrf_drv_gpiote.h"
#include "nrf_drv_ppi.h"
#include "..\brk_log.h"


void pa_lna_init(uint32_t gpio_pa_pin, uint32_t gpio_lna_pin)
{
    ble_opt_t opt;
    uint32_t gpiote_ch = 0;
    ret_code_t err_code;        

#if 1
    nrf_gpio_cfg_output(gpio_pa_pin);
    nrf_gpio_pin_clear(gpio_pa_pin);
    nrf_gpio_cfg_output(gpio_lna_pin);
    nrf_gpio_pin_clear(gpio_lna_pin);
#endif

    memset(&opt, 0, sizeof(ble_opt_t));
    
    err_code = nrf_drv_gpiote_init();
    if(err_code != NRF_ERROR_INVALID_STATE)
        APP_ERROR_CHECK(err_code);
    

    nrf_ppi_channel_t ppi_set_ch;
    nrf_ppi_channel_t ppi_clr_ch;


    err_code = nrf_drv_ppi_init();
    if(err_code != NRF_ERROR_MODULE_ALREADY_INITIALIZED)
        APP_ERROR_CHECK(err_code);
    

    err_code = nrf_drv_ppi_channel_alloc(&ppi_set_ch);
    APP_ERROR_CHECK(err_code);
    
    err_code = nrf_drv_ppi_channel_alloc(&ppi_clr_ch);
    APP_ERROR_CHECK(err_code);


    nrf_drv_gpiote_out_config_t config = GPIOTE_CONFIG_OUT_TASK_TOGGLE(false);
    
    if((gpio_pa_pin == 0) && (gpio_lna_pin == 0))
    {
        err_code = NRF_ERROR_INVALID_PARAM;
        APP_ERROR_CHECK(err_code);
    }    

    if(gpio_pa_pin != 0)
    {
        if(gpiote_ch == 0)
        {
            err_code = nrf_drv_gpiote_out_init(gpio_pa_pin, &config);
            APP_ERROR_CHECK(err_code);
            
            gpiote_ch = nrf_drv_gpiote_out_task_addr_get(gpio_pa_pin); 
        }
        
        // PA config
        opt.common_opt.pa_lna.pa_cfg.active_high = 1;   // Set the pin to be active high
        opt.common_opt.pa_lna.pa_cfg.enable      = 1;   // Enable toggling
        opt.common_opt.pa_lna.pa_cfg.gpio_pin    = gpio_pa_pin; // The GPIO pin to toggle tx

        BRK_COLOR_LOG_INFO(BOLD_YELLOW_PRINT,"[dbg] gpiote_ch:%d pa pin : %d\n",gpiote_ch,gpio_pa_pin);

    }
    
    if(gpio_lna_pin != 0)
    {
        if(gpiote_ch == 0)
        {
            err_code = nrf_drv_gpiote_out_init(gpio_lna_pin, &config);
            APP_ERROR_CHECK(err_code);        
            
            gpiote_ch = nrf_drv_gpiote_out_task_addr_get(gpio_lna_pin); 
        }
        
        // LNA config
        opt.common_opt.pa_lna.lna_cfg.active_high  = 1; // Set the pin to be active high
        opt.common_opt.pa_lna.lna_cfg.enable       = 1; // Enable toggling
        opt.common_opt.pa_lna.lna_cfg.gpio_pin     = gpio_lna_pin;  // The GPIO pin to toggle rx

        BRK_COLOR_LOG_INFO(BOLD_YELLOW_PRINT,"[dbg] gpiote_ch:%d lna pin : %d\n",gpiote_ch,gpio_lna_pin);

    }

    // Common PA/LNA config
    opt.common_opt.pa_lna.gpiote_ch_id  = (gpiote_ch - NRF_GPIOTE_BASE) >> 2;   // GPIOTE channel used for radio pin toggling
    opt.common_opt.pa_lna.ppi_ch_id_clr = ppi_clr_ch;   // PPI channel used for radio pin clearing
    opt.common_opt.pa_lna.ppi_ch_id_set = ppi_set_ch;   // PPI channel used for radio pin setting
    
    err_code = sd_ble_opt_set(BLE_COMMON_OPT_PA_LNA, &opt);

    BRK_COLOR_LOG_INFO(BOLD_YELLOW_PRINT,"[dbg] BLE_COMMON_OPT_PA_LNA : %d\n",err_code);
    APP_ERROR_CHECK(err_code);    
}

#if defined(GPIOTE_HANDLER_SD)
int g_p_cnt=0;
void (*g_func_ptr)(void);
int g_pin;
// GPIOTE event handler
void gpiote_event_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
    // Handle the GPIOTE event
    if (pin == g_pin) {
        // Do something when the event occurs
    	g_func_ptr();
    }
    g_p_cnt++;
}


//      LOW 0
//      HIGH 1
#define CHANGE 2
#define FALLING 3
#define RISING 4

int attachInterrupt_sd(uint32_t pin, voidFuncPtr callback, uint32_t mode)
{
	uint32_t polarity;
    ret_code_t err_code;
    nrf_drv_gpiote_in_config_t in_config = GPIOTE_CONFIG_IN_SENSE_TOGGLE(true);
    in_config.pull = NRF_GPIO_PIN_PULLUP;

	//if (pin >= PINS_COUNT) {
	//    return 0;
	//  }

    // Configure the GPIOTE event for a specific pin

    if (mode == CHANGE)
    	in_config.sense = NRF_GPIOTE_POLARITY_TOGGLE;
    else if (mode==FALLING)
    	in_config.sense = NRF_GPIOTE_POLARITY_HITOLO;
    else if (mode==RISING)
    	in_config.sense = NRF_GPIOTE_POLARITY_LOTOHI;
    //else
    //	return 0;

    //in_config.pull = NRF_GPIO_PIN_PULLUP;

	pin = g_ADigitalPinMap[pin];

	g_func_ptr = callback;
	g_pin = pin;

    // Initialize the GPIOTE driver
    err_code = nrf_drv_gpiote_init();
    APP_ERROR_CHECK(err_code);

    err_code = nrf_drv_gpiote_in_init(pin, &in_config, gpiote_event_handler);
    APP_ERROR_CHECK(err_code);

    // Enable the GPIOTE event
    nrf_drv_gpiote_in_event_enable(pin, true);
}


#endif
