#ifndef PA_LNA_H__
#define PA_LNA_H__

#include "ble.h"
#include "app_error.h"
#include "nrf_drv_gpiote.h"
#include "nrf_drv_ppi.h"

#define GPIOTE_HANDLER_SD

#if defined(GPIOTE_HANDLER_SD)
typedef void (*voidFuncPtr)(void);
#endif


#ifdef __cplusplus
extern "C" {
#endif

#if defined(GPIOTE_HANDLER_SD)
extern int g_p_cnt;
int attachInterrupt_sd(uint32_t pin, voidFuncPtr callback, uint32_t mode);
#endif

void pa_lna_init(uint32_t gpio_pa_pin, uint32_t gpio_lna_pin);

#ifdef __cplusplus
}
#endif

#endif
