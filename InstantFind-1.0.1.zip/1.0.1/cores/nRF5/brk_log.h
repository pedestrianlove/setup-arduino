//============================================================================
//
// Name        : brk_log.h
// Author      : Ebony Huang
// Created on  : Feb 20, 2020
// Version     : TODO
// Description : TODO
//
// Copyright 2019,2020 , Brickcom Corporation
// All Rights Reserved.
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Brickcom Corporation;
// the contents of this file may not be disclosed to third parties, copied
// or duplicated in any form, in whole or in part, without the prior
// written permission of Brickcom Corporation.
//
//============================================================================
#ifndef _BRK_LOG_H_
#define _BRK_LOG_H_

#include <Arduino.h> 
#include <stdio.h>
#include <stdlib.h>
//#include <stdint.h>



#ifdef __cplusplus
extern "C"
{
#endif

#define	_LOG_EMERG				0	/* system is unusable */
#define	_LOG_ALERT				1	/* action must be taken immediately */
#define	_LOG_CRIT				2	/* critical conditions */
#define	_LOG_ERR				3	/* error conditions */
#define	_LOG_WARNING			4	/* warning conditions */
#define	_LOG_NOTICE				5	/* normal but significant condition */
#define	_LOG_INFO				6	/* informational */
#define	_LOG_DEBUG				7	/* debug-level messages */
#define _LOG_USER			    8


#ifndef LOG_INFO
#define LOG_ALERT				_LOG_ALERT
#define LOG_CRIT 				_LOG_CRIT
#define LOG_ERR 				_LOG_ERR
#define LOG_WARNING 			_LOG_WARNING
#define LOG_NOTICE 				_LOG_NOTICE
#define LOG_INFO 				_LOG_INFO
#define LOG_DEBUG 				_LOG_DEBUG
#define LOG_USER 				_LOG_USER
#endif


#if defined(DEBUG)
#undef DBG_LOG_LEVEL
#define DBG_LOG_LEVEL			_LOG_INFO
#endif

#if defined(DEBUG_FULL)
#undef DBG_LOG_LEVEL
#define DBG_LOG_LEVEL			_LOG_DEBUG
#define NRF_51822_DEBUG
#endif


#if !defined(DBG_LOG_LEVEL)
#define DBG_LOG_LEVEL			_LOG_INFO
#endif



#define BOLD_BLACK_PRINT    	"\033[1;30m"
#define BOLD_RED_PRINT      	"\033[1;31m"
#define BOLD_GREEN_PRINT    	"\033[1;32m"
#define BOLD_YELLOW_PRINT   	"\033[1;33m"
#define BOLD_BLUE_PRINT     	"\033[1;34m"
#define BOLD_PURPLE_PRINT   	"\033[1;35m"
#define BOLD_CYAN_PRINT     	"\033[1;36m"
#define BOLD_WHITE_PRINT    	"\033[1;37m"

#define BLACK_PRINT    			"\033[0;30m"
#define RED_PRINT      			"\033[0;31m"
#define GREEN_PRINT    			"\033[0;32m"
#define YELLOW_PRINT   			"\033[0;33m"
#define BLUE_PRINT     			"\033[0;34m"
#define PURPLE_PRINT  			"\033[0;35m"
#define CYAN_PRINT     			"\033[0;36m"
#define WHITE_PRINT    			"\033[0;37m"

#define RESEST_PRINT   			"\033[0m"
#define NORMAL_PRINT   			"\033[0m"


/*
 // The stdout stream is buffered, so will only display what's in the buffer after it reaches a newline (or when it's told to).
 // You have a few options to print immediately
 // either fflush after printf or set the stdout no buffer
 */



#if defined(RELEASE)

#define brk_debug_init()
#define brk_debug_printf(fmt,...)
#define BRK_LOG(level, fmt, ...)
#define BRK_COLOR_LOG(level,color,fmt,...)
#define BRK_LOG_COLOR(x)
#define BRK_LOG_COLOR_SET(x)

#else

#if !defined(DEFAULT_SERIAL_BAUDRATE)
#define DEFAULT_SERIAL_BAUDRATE     115200
#endif

#define brk_debug_init()			Serial.begin(DEFAULT_SERIAL_BAUDRATE)
#define brk_debug_printf(fmt,...)	brk_uart_printf(fmt,##__VA_ARGS__)
//Serial.printf(fmt,##__VA_ARGS__)

// define COLOR_DEBUG or MONO_DEBUG
#if defined(COLOR_DEBUG)
#define BRK_LOG_COLOR(x)    		brk_debug_printf(x)
#define BRK_LOG_COLOR_SET(x)    	brk_debug_printf(x)
#else
#define BRK_LOG_COLOR(x)
#define BRK_LOG_COLOR_SET(x)
#endif


#define BRK_LOG(level,fmt,...) \
    do { if (level<=DBG_LOG_LEVEL) {  brk_debug_printf(fmt,##__VA_ARGS__); } } while(0)
#define BRK_COLOR_LOG(level,color,fmt,...) \
    do { if (level<=DBG_LOG_LEVEL) { BRK_LOG_COLOR(color); brk_debug_printf(fmt,##__VA_ARGS__); BRK_LOG_COLOR(NORMAL_PRINT);} } while(0)

#endif


#define BRK_LOG_USER(fmt,...)    				BRK_LOG(_LOG_USER,fmt,##__VA_ARGS__)
#define BRK_LOG_DEBUG(fmt,...)   				BRK_LOG(_LOG_DEBUG,fmt,##__VA_ARGS__)
#define BRK_LOG_INFO(fmt,...)    				BRK_LOG(_LOG_INFO,fmt,##__VA_ARGS__)
#define BRK_LOG_NOTICE(fmt,...)  				BRK_LOG(_LOG_NOTICE,fmt,##__VA_ARGS__)
#define BRK_LOG_WARNING(fmt,...) 				BRK_LOG(_LOG_WARNING,fmt,##__VA_ARGS__)

#define BRK_COLOR_LOG_USER(color,fmt,...)    	BRK_COLOR_LOG(_LOG_USER,color,fmt,##__VA_ARGS__)
#define BRK_COLOR_LOG_DEBUG(color,fmt,...)   	BRK_COLOR_LOG(_LOG_DEBUG,color,fmt,##__VA_ARGS__)
#define BRK_COLOR_LOG_INFO(color,fmt,...)    	BRK_COLOR_LOG(_LOG_INFO,color,fmt,##__VA_ARGS__)
#define BRK_COLOR_LOG_NOTICE(color,fmt,...)  	BRK_COLOR_LOG(_LOG_NOTICE,color,fmt,##__VA_ARGS__)
#define BRK_COLOR_LOG_WARNING(color,fmt,...) 	BRK_COLOR_LOG(_LOG_WARNING,color,fmt,##__VA_ARGS__)




int brk_uart_printf(const char *format,...);

#ifdef __cplusplus
}
#endif

#endif //_BRK_LOG_H_
