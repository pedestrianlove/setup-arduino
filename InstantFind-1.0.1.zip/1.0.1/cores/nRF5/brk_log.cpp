//============================================================================
//
// Name        : brk_log.h
// Author      : Ebony Huang
// Created on  : Feb 20, 2020
// Version     : TODO
// Description : TODO
//
// Copyright 2019,2020 , Brickcom Corporation
// All Rights Reserved.
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Brickcom Corporation;
// the contents of this file may not be disclosed to third parties, copied
// or duplicated in any form, in whole or in part, without the prior
// written permission of Brickcom Corporation.
//
//============================================================================

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "Arduino.h"
#include "brk_log.h"

int brk_uart_printf(const char *format,...)
{
	char buf[256];
	int len;
	int i, j;

	va_list ap;
	va_start(ap, format);

	len = vsnprintf(buf, 256, format, ap);

	for (j = i = 0; i < len; i++)
	{
		if (buf[i] == '\n')
		{
			if ((i>0) && (buf[j]!='\r'))
				Serial.print('\r');
		}
		Serial.print(buf[i]);
		j=i;
	}
	va_end(ap);
	return len;
}
