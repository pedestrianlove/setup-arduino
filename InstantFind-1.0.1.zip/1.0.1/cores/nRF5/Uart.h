//============================================================================
//
// Name        : Uart.h
// Author      : Brickcom
// Created on  : 2024-05-15
// Version     : TODO
// Description : TODO
//
// Copyright 2020~2024 , Brickcom Corporation
// All Rights Reserved.
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Brickcom Corporation;
// the contents of this file may not be disclosed to third parties, copied
// or duplicated in any form, in whole or in part, without the prior
// written permission of Brickcom Corporation.
//
//============================================================================


#ifndef INSTANTFIND_HARDWARE_INSTANTFIND_1_0_0_CORES_NRF5_UART_H_
#define INSTANTFIND_HARDWARE_INSTANTFIND_1_0_0_CORES_NRF5_UART_H_

#if defined(NRF52840_XXAA)
#define USING_UARTE
#endif

#if defined(USING_UARTE)
#include "Uart_uarte.h"
#else
#include "Uart_uart.h"
#endif



#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif

#endif /* INSTANTFIND_HARDWARE_INSTANTFIND_1_0_0_CORES_NRF5_UART_H_ */
