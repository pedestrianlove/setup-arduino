//============================================================================
//
// Name        : nRF51822.cpp
// Author      : Brickcom
// Created on  : 2024-05-19
// Version     : TODO
// Description : TODO
//
// Copyright 2020~2024 , Brickcom Corporation
// All Rights Reserved.
// This is UNPUBLISHED PROPRIETARY SOURCE CODE of Brickcom Corporation;
// the contents of this file may not be disclosed to third parties, copied
// or duplicated in any form, in whole or in part, without the prior
// written permission of Brickcom Corporation.
//
//============================================================================





