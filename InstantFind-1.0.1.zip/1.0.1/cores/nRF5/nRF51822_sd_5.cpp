#if (NRF_SD_BLE_API_VERSION>=5)


// Licensed under the MIT license. See LICENSE file in the project root for full license information.

//#define NRF_SD_BLE_API_VERSION 5
//#define NRF_51822_DEBUG

#include "brk_log.h"
#include "utility/pa_lna.h"

#include "bleConstants.h"
#if defined(NRF51) || defined(NRF52) || defined(__RFduino__)

#ifdef __RFduino__
  #include <utility/RFduino/ble.h>
  #include <utility/RFduino/ble_hci.h>
  #include <utility/RFduino/nrf_sdm.h>
//#error 1
#elif defined(NRF5) || defined(NRF51_S130)
  #include <ble.h>
  #include <ble_hci.h>
  #include <nrf_sdm.h>
//#error 2
#elif defined(NRF52) && defined(S132) // ARDUINO_RBL_nRF52832
  #ifndef ARDUINO_RBL_nRF52832
    #define ARDUINO_RBL_nRF52832
  #endif
//#error 3
  #include <sdk/softdevice/s132/headers/nrf_ble.h>
  #include <sdk/softdevice/s132/headers/nrf_ble_hci.h>
  #include <sdk/softdevice/s132/headers/nrf_sdm.h>
#else
//#error 4
  #include <s110/ble.h>
  #include <s110/ble_hci.h>
  #include <s110/nrf_sdm.h>
#endif

#if defined(NRF5) || defined(NRF51_S130) || defined(ARDUINO_RBL_nRF52832)
//#error 5
uint32_t sd_ble_gatts_value_set(uint16_t handle, uint16_t offset, uint16_t* const p_len, uint8_t const * const p_value) {
  ble_gatts_value_t val;

  val.len = *p_len;
  val.offset = offset;
  val.p_value = (uint8_t*)p_value;
  return sd_ble_gatts_value_set(BLE_CONN_HANDLE_INVALID, handle, &val);
}
#endif

#include "Arduino.h"

#include "BLEAttribute.h"
#include "BLEService.h"
#include "BLECharacteristic.h"
#include "BLEDescriptor.h"
#include "BLEUtil.h"
#include "BLEUuid.h"

#include "nRF51822.h"

// #define NRF_51822_DEBUG

// brickcom
#if NRF_SD_BLE_API_VERSION!=2
#if !defined(GATT_MTU_SIZE_DEFAULT)
#define GATT_MTU_SIZE_DEFAULT	BLE_GATT_ATT_MTU_DEFAULT
#endif

#if !defined(BLE_EVTS_PTR_ALIGNMENT)
#define BLE_EVTS_PTR_ALIGNMENT	BLE_EVT_PTR_ALIGNMENT
#endif

#ifndef BLE_GATTS_ATTR_TAB_SIZE
  #define BLE_GATTS_ATTR_TAB_SIZE        248
#endif

#else

#ifndef BLE_GATTS_ATTR_TAB_SIZE
  #define BLE_GATTS_ATTR_TAB_SIZE        BLE_GATTS_ATTR_TAB_SIZE_DEFAULT  //248
#endif

#endif
// brickcom

#define BLE_STACK_EVT_MSG_BUF_SIZE       (sizeof(ble_evt_t) + (GATT_MTU_SIZE_DEFAULT))

#ifndef BLE_GATTS_ATTR_TAB_SIZE
  #define BLE_GATTS_ATTR_TAB_SIZE        BLE_GATTS_ATTR_TAB_SIZE_DEFAULT  //248
#endif

#define SCAN_INTERVAL_MS  100
#define WINDOW_LEN_MS    (SCAN_INTERVAL_MS / 4)
#define MAX_ADV_PACK_LEN (BLE_GAP_ADV_MAX_SIZE + BLE_GAP_ADDR_LEN + 2)
#define ADV_TYPE_LEN      2
#define BEACON_DATA_LEN   21

#ifdef __cplusplus
extern "C" {
#endif
static void initScanParams();
#ifdef __cplusplus
}
#endif
	
nRF51822::nRF51822() :
  BLEDevice(),

  _advDataLen(0),
  _hasScanData(false),
  _broadcastCharacteristic(NULL),

  _connectionHandle(BLE_CONN_HANDLE_INVALID),

  _txBufferCount(0),

  _numLocalCharacteristics(0),
  _localCharacteristicInfo(NULL),

  _numRemoteServices(0),
  _remoteServiceInfo(NULL),
  _remoteServiceDiscoveryIndex(0),
  _numRemoteCharacteristics(0),
  _remoteCharacteristicInfo(NULL),
  _remoteRequestInProgress(false),
  _init(0),
  _adv_started(0),
  _tx_Power(DEFAULT_BLE_TX_POWER)
{
#if defined(NRF5) || defined(NRF51_S130)
  this->_encKey = (ble_gap_enc_key_t*)&this->_bondData;
  memset(&this->_bondData, 0, sizeof(this->_bondData));
#else
  this->_authStatus = (ble_gap_evt_auth_status_t*)&this->_authStatusBuffer;
  memset(&this->_authStatusBuffer, 0, sizeof(this->_authStatusBuffer));
#endif
  _gapAddress.addr_type = 0xFF;

  initScanParams();
}

nRF51822::~nRF51822() {
  this->end();
}

#ifdef __cplusplus
extern "C" {
#endif

static  ble_gap_scan_params_t scan_params;

static void initScanParams() {
    memset(&scan_params, 0, sizeof(scan_params));
    scan_params.active      = false; 

#if (NRF_SD_BLE_API_VERSION == 2)
    scan_params.selective   = false;
    scan_params.p_whitelist = NULL;
#endif
#if (NRF_SD_BLE_API_VERSION == 3)
	scan_params.use_whitelist = 0;
#endif
    scan_params.interval    = MSEC_TO_UNITS(SCAN_INTERVAL_MS, UNIT_0_625_MS); 
    scan_params.window      = MSEC_TO_UNITS(WINDOW_LEN_MS, UNIT_0_625_MS);    
    scan_params.timeout     = 0; // disable timeout

}

#if 0 //softdevice 2.0.1
static void ble_stack_init(void)
{
    uint32_t err_code;

    nrf_clock_lf_cfg_t clock_lf_cfg = NRF_CLOCK_LFCLKSRC;

    // Initialize the SoftDevice handler module.
    SOFTDEVICE_HANDLER_INIT(&clock_lf_cfg, NULL);

    ble_enable_params_t ble_enable_params;
    err_code = softdevice_enable_get_default_config(CENTRAL_LINK_COUNT,
                                                    PERIPHERAL_LINK_COUNT,
                                                    &ble_enable_params);
    APP_ERROR_CHECK(err_code);

    //Check the ram settings against the used number of links
    CHECK_RAM_START_ADDR(CENTRAL_LINK_COUNT,PERIPHERAL_LINK_COUNT);

    // Enable BLE stack.
    err_code = softdevice_enable(&ble_enable_params);
    APP_ERROR_CHECK(err_code);
}
#endif


#if (NRF_SD_BLE_API_VERSION == 5)

/**
 * Function is implemented as weak so that it can be overwritten by custom application error handler
 * when needed.
 */
__WEAK void app_error_fault_handler(uint32_t id, uint32_t pc, uint32_t info)
{

    NVIC_SystemReset();
}


void BLEPeripheralStartSoftDevice() {

	int ret;
	// Configure Clock
	#if defined( USE_LFXO )
	nrf_clock_lf_cfg_t const clock_cfg =
	{
	  // LFXO
	  .source        = NRF_CLOCK_LF_SRC_XTAL,
	  .rc_ctiv       = 0,
	  .rc_temp_ctiv  = 0,
	  .accuracy      = NRF_CLOCK_LF_ACCURACY_20_PPM
	};
	#elif defined( USE_LFRC )
	nrf_clock_lf_cfg_t const clock_cfg =
	{
	  // LFRC
	  .source        = NRF_CLOCK_LF_SRC_RC,
	  .rc_ctiv       = 16,
	  .rc_temp_ctiv  = 2,
	  .accuracy      = NRF_CLOCK_LF_ACCURACY_250_PPM
	};
	#else
	//#error Clock Source is not configured, define USE_LFXO or USE_LFRC according to your board in variant.h
	nrf_clock_lf_cfg_t const clock_cfg =
	{
	  // LFXO
	  .source        = NRF_CLOCK_LF_SRC_XTAL,
	  .rc_ctiv       = 0,
	  .rc_temp_ctiv  = 0,
	  .accuracy      = NRF_CLOCK_LF_ACCURACY_20_PPM
	};
	#endif


	ret = sd_softdevice_enable(&clock_cfg, app_error_fault_handler);

    //BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] enable softdevice %d\n",ret);
    //,errorCode==0?"SUCCESS":"FAIL");
	//Serial.begin(115200);
	// Enable SoftDevice
    //Serial.print("sd_softdevice_enable ");
    //Serial.println(ret);

}

#else

void BLEPeripheralStartSoftDevice() {
	/**  test code for RC low freq clock
    nrf_clock_lf_cfg_t cfg = {
      .source        = NRF_CLOCK_LF_SRC_RC,
      .rc_ctiv       = 16,  // SEE NOTES IN lp_timer.cpp
      .rc_temp_ctiv  = 2,
      .xtal_accuracy = 0 // not used NRF_CLOCK_LF_XTAL_ACCURACY_250_PPM
    };
	sd_softdevice_enable(&cfg, NULL);
	***/
#ifdef __RFduino__
  sd_softdevice_enable(NRF_CLOCK_LFCLKSRC_SYNTH_250_PPM, NULL);
#elif defined(NRF5) && !defined(S110)
  #if defined(USE_LFRC)
//#error asdad
    nrf_clock_lf_cfg_t cfg = {
      .source        = NRF_CLOCK_LF_SRC_RC,
      .rc_ctiv       = 16,  // SEE NOTES IN lp_timer.cpp
      .rc_temp_ctiv  = 2,
      .xtal_accuracy = 0 // not used NRF_CLOCK_LF_XTAL_ACCURACY_250_PPM
    };
  #elif defined(USE_LFSYNT)
  
    nrf_clock_lf_cfg_t cfg = {
      .source        = NRF_CLOCK_LF_SRC_SYNTH,
      .rc_ctiv       = 0,
      .rc_temp_ctiv  = 0,
      .xtal_accuracy = NRF_CLOCK_LF_XTAL_ACCURACY_250_PPM
    };
  
  #else
    //default USE_LFXO
    nrf_clock_lf_cfg_t cfg = {
      .source        = NRF_CLOCK_LF_SRC_XTAL,
      .rc_ctiv       = 0,
      .rc_temp_ctiv  = 0,
      .xtal_accuracy = NRF_CLOCK_LF_XTAL_ACCURACY_20_PPM
    };
  #endif
  
  int ret = sd_softdevice_enable(&cfg, NULL);
  //Serial.begin(115200);
  //BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] enable softdevice %d\n",ret);
  //Serial.print("sd_softdevice_enable ");
  //Serial.println(ret);
  
#else
  #if defined(USE_LFRC)
    sd_softdevice_enable(NRF_CLOCK_LFCLKSRC_RC_250_PPM_250MS_CALIBRATION, NULL);
  #elif defined(USE_LFSYNT)
    sd_softdevice_enable(NRF_CLOCK_LFCLKSRC_SYNTH_250_PPM, NULL);
  #else
    //default USE_LFXO
    sd_softdevice_enable(NRF_CLOCK_LFCLKSRC_XTAL_20_PPM, NULL);
  #endif
#endif
}

#endif


#ifdef __cplusplus
}
#endif

    // update these while not scanning and then call startScanning() to apply them 
void nRF51822::setScanInterval(uint16_t interval, uint16_t window) {
	// in units of 0.625 ms,  default 160,40  i.e. 100ms,25ms
    scan_params.interval    = interval; 
    scan_params.window      = window;    
}

void nRF51822::setActiveScan(bool enable) {
	// Request scan response data, default is false
    scan_params.active      = enable;
}

void nRF51822::setScanTimeout(uint16_t timeout) {
	// 0 = Don't stop scanning after n seconds
    scan_params.timeout     = timeout;
}    


// define this to print out to serial the min ram needed
// then set 
//C:\Users\matthew\AppData\Local\Arduino15\packages\sandeepmistry\hardware\nRF5\0.6.0\cores\nRF5\SDK\components\softdevice\s132\toolchain\armgcc
// armgcc_s132_nrf52832_xxaa.ld  
// RAM (rwx) :  ORIGIN = 0x20002080, LENGTH = 0xdf80
// actually returned 20002078 but add 8 bytes (possible corruption)
//#define DEBUG_RAM_BASE  
// NOTE: must have called Serial.begin(...) in sketch before ble begin()

void nRF51822::begin(unsigned char advertisementDataSize,
                      BLEEirData *advertisementData,
                      unsigned char scanDataSize,
                      BLEEirData *scanData,
                      BLELocalAttribute** localAttributes,
                      unsigned char numLocalAttributes,
                      BLERemoteAttribute** remoteAttributes,
                      unsigned char numRemoteAttributes)
{

// BLEPeripheralStartSoftDevice(); called in main.cpp to startup softdevice and LC clock
uint32_t errorCode = 0;
uint32_t app_ram_base_required = 0;


#if defined(NRF5) && !defined(S110)
  extern uint32_t __data_start__;
  uint32_t app_ram_base = (uint32_t) &__data_start__;
  

  #if NRF_SD_BLE_API_VERSION!=2
  // Overwrite some of the default configurations for the BLE stack.
  ble_cfg_t ble_cfg;


#define NRF_SDH_BLE_TOTAL_LINK_COUNT 1
#define NRF_SDH_BLE_GAP_EVENT_LENGTH 3

  memset(&ble_cfg, 0, sizeof(ble_cfg));
  ble_cfg.conn_cfg.conn_cfg_tag                     = 1;
  ble_cfg.conn_cfg.params.gap_conn_cfg.conn_count   = NRF_SDH_BLE_TOTAL_LINK_COUNT;
  ble_cfg.conn_cfg.params.gap_conn_cfg.event_length = NRF_SDH_BLE_GAP_EVENT_LENGTH;
  errorCode = sd_ble_cfg_set(BLE_CONN_CFG_GAP, &ble_cfg, app_ram_base);

  //Serial.println(errorCode);

  // Configure the maximum number of connections.
  memset(&ble_cfg, 0, sizeof(ble_cfg));
  ble_cfg.conn_cfg.conn_cfg_tag = 1;
  ble_cfg.gap_cfg.role_count_cfg.periph_role_count  = 2; // 0;
  #if !defined (S112)
  ble_cfg.gap_cfg.role_count_cfg.central_role_count = 0;
  ble_cfg.gap_cfg.role_count_cfg.central_sec_count  = 0;
  #endif // !defined (S112)
  errorCode = sd_ble_cfg_set(BLE_GAP_CFG_ROLE_COUNT, &ble_cfg, app_ram_base);

  //Serial.println(errorCode);

#if 1
  // Configure the maximum ATT MTU.
  memset(&ble_cfg, 0x00, sizeof(ble_cfg));
  ble_cfg.conn_cfg.conn_cfg_tag = 1;
  ble_cfg.conn_cfg.params.gatt_conn_cfg.att_mtu = GATT_MTU_SIZE_DEFAULT;
  errorCode = sd_ble_cfg_set(BLE_CONN_CFG_GATT, &ble_cfg, app_ram_base);

  //Serial.println(errorCode);
#endif

  // Configure number of custom UUIDS.
  memset(&ble_cfg, 0, sizeof(ble_cfg));
  ble_cfg.common_cfg.vs_uuid_cfg.vs_uuid_count = 10;
  errorCode = sd_ble_cfg_set(BLE_COMMON_CFG_VS_UUID, &ble_cfg, app_ram_base);

  //Serial.println(errorCode);

  // Configure the GATTS attribute table.
  memset(&ble_cfg, 0x00, sizeof(ble_cfg));
  ble_cfg.gatts_cfg.attr_tab_size.attr_tab_size = 248; // BLE_GATTS_ATTR_TAB_SIZE;
  errorCode = sd_ble_cfg_set(BLE_GATTS_CFG_ATTR_TAB_SIZE, &ble_cfg, app_ram_base);

  //Serial.println(errorCode);

  // Configure Service Changed characteristic.
  memset(&ble_cfg, 0x00, sizeof(ble_cfg));
  ble_cfg.gatts_cfg.service_changed.service_changed = 0;
  errorCode = sd_ble_cfg_set(BLE_GATTS_CFG_SERVICE_CHANGED, &ble_cfg, app_ram_base);

  //Serial.println(errorCode);

  // Enable BLE stack.
  if (_init==0)
  {
	  errorCode = sd_ble_enable(&app_ram_base);
	  if (errorCode == NRF_SUCCESS)
		  _init = 1;
	  BRK_COLOR_LOG_DEBUG((errorCode==NRF_SUCCESS?BOLD_GREEN_PRINT:BOLD_RED_PRINT),"[ble] Softdevice addr:0x%x enable ble stack:%s\n",app_ram_base,errorCode==0?"Success":"Fail");
  }


  #else

  ble_enable_params_t enableParams;

  memset(&enableParams, 0, sizeof(ble_enable_params_t));
  enableParams.common_enable_params.vs_uuid_count   = 10;
  enableParams.gatts_enable_params.attr_tab_size    = BLE_GATTS_ATTR_TAB_SIZE;
  enableParams.gatts_enable_params.service_changed  = 1;
  enableParams.gap_enable_params.periph_conn_count  = 1;
  enableParams.gap_enable_params.central_conn_count = 0;
  enableParams.gap_enable_params.central_sec_count  = 0;

#ifdef DEBUG_RAM_BASE  
  //errorCode = sd_ble_enable(&enableParams, &app_ram_base); // testing
  errorCode = sd_ble_enable(&enableParams, &app_ram_base_required);

  Serial.print(F("sd_ble_enable = "));
  Serial.print(errorCode);
  Serial.print(F("  sd Ram Required = "));
  Serial.println(app_ram_base_required, HEX);
  Serial.print(F("  __data_start__ = "));
  Serial.println(__data_start__, HEX);
  
#else
  errorCode = sd_ble_enable(&enableParams, &app_ram_base); // normal call should return 0
#endif  
  
  #endif
  
#elif defined(S110)
  ble_enable_params_t enableParams = {
      .gatts_enable_params = {
          .service_changed = true,
          .attr_tab_size = BLE_GATTS_ATTR_TAB_SIZE
      }
  };

  sd_ble_enable(&enableParams);
#elif defined(NRF51_S130)
  ble_enable_params_t enableParams = {
      .gatts_enable_params = {
          .service_changed = true
      }
  };

  sd_ble_enable(&enableParams);
#endif


#if defined(NRF_51822_DEBUG)

  //uint8_t   version_number;             /**< Link Layer Version number for BT 4.1 spec is 7 (https://www.bluetooth.org/en-us/specification/assigned-numbers/link-layer). */
  //uint16_t  company_id;                 /**< Company ID, Nordic Semiconductor's company ID is 89 (0x0059) (https://www.bluetooth.org/apps/content/Default.aspx?doc_id=49708). */
  //uint16_t  subversion_number;          /**< Link Layer Sub Version number, corresponds to the SoftDevice Config ID or Firmware ID (FWID). */

  ble_version_t version;
  sd_ble_version_get(&version);

  BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] Softdevice version ver:%x company_id:0x%04x firmare:0x%04X(%d)\n",
		  version.version_number,version.company_id,version.subversion_number,version.subversion_number);
#if 0
  Serial.print(F("version = "));
  Serial.print(version.version_number);
  Serial.print(F(" "));
  Serial.print(version.company_id);
  Serial.print(F(" "));
  Serial.print(version.subversion_number);
  Serial.println();
#endif

#endif

  ble_gap_conn_params_t gap_conn_params;

  gap_conn_params.min_conn_interval = (DEFAULT_MIN_CONNECTION_INTERVAL_ms * 8) / 10;  // in 1.25ms units
  gap_conn_params.max_conn_interval = (DEFAULT_MAX_CONNECTION_INTERVAL_ms * 8) / 10;  // in 1.25ms unit
  gap_conn_params.slave_latency     = 0;
  gap_conn_params.conn_sup_timeout  = DEFAULT_CONNECTION_SUPERVISION_TIMEOUT_ms / 10; // in 10ms unit

  sd_ble_gap_ppcp_set(&gap_conn_params);

  ble_tx_power_activate();
  //sd_ble_gap_tx_power_set(DEFAULT_BLE_TX_POWER);
  //pa_lna_init(18,20);

  unsigned char srData[31];
  unsigned char srDataLen = 0;

  this->_advDataLen = 0;

#if 0  // Ebony
  // flags
  this->_advData[this->_advDataLen + 0] = 2;
  this->_advData[this->_advDataLen + 1] = 0x01;
  this->_advData[this->_advDataLen + 2] = 0x06;

  this->_advDataLen += 3;
#endif

  if (advertisementDataSize && advertisementData) {
    for (int i = 0; i < advertisementDataSize; i++) {
      this->_advData[this->_advDataLen + 0] = advertisementData[i].length + 1;
      this->_advData[this->_advDataLen + 1] = advertisementData[i].type;
      this->_advDataLen += 2;

      memcpy(&this->_advData[this->_advDataLen], advertisementData[i].data, advertisementData[i].length);

      this->_advDataLen += advertisementData[i].length;
    }
  }

  if (scanDataSize && scanData) {
    for (int i = 0; i < scanDataSize; i++) {
      srData[srDataLen + 0] = scanData[i].length + 1;
      srData[srDataLen + 1] = scanData[i].type;
      srDataLen += 2;

      memcpy(&srData[srDataLen], scanData[i].data, scanData[i].length);

      srDataLen += scanData[i].length;
      _hasScanData = true;
    }
  }

  sd_ble_gap_adv_data_set(this->_advData, this->_advDataLen, srData, srDataLen);
  sd_ble_gap_appearance_set(0);

  for (int i = 0; i < numLocalAttributes; i++) {
    BLELocalAttribute *localAttribute = localAttributes[i];

    if (localAttribute->type() == BLETypeCharacteristic) {
      this->_numLocalCharacteristics++;
    }
  }

  this->_numLocalCharacteristics -= 3; // 0x2a00, 0x2a01, 0x2a05

  this->_localCharacteristicInfo = (struct localCharacteristicInfo*)malloc(sizeof(struct localCharacteristicInfo) * this->_numLocalCharacteristics);

  unsigned char localCharacteristicIndex = 0;

  uint16_t handle = 0;
  BLEService *lastService = NULL;

  for (int i = 0; i < numLocalAttributes; i++) {
    BLELocalAttribute *localAttribute = localAttributes[i];
    BLEUuid uuid = BLEUuid(localAttribute->uuid());
    const unsigned char* uuidData = uuid.data();
    unsigned char value[255];

    ble_uuid_t nordicUUID;

    if (uuid.length() == 2) {
      nordicUUID.uuid = (uuidData[1] << 8) | uuidData[0];
      nordicUUID.type = BLE_UUID_TYPE_BLE;
    } else {
      unsigned char uuidDataTemp[16];

      memcpy(&uuidDataTemp, uuidData, sizeof(uuidDataTemp));

      nordicUUID.uuid = (uuidData[13] << 8) | uuidData[12];

      uuidDataTemp[13] = 0;
      uuidDataTemp[12] = 0;

      sd_ble_uuid_vs_add((ble_uuid128_t*)&uuidDataTemp, &nordicUUID.type);
    }

    if (localAttribute->type() == BLETypeService) {
      BLEService *service = (BLEService *)localAttribute;

      if (strcmp(service->uuid(), "1800") == 0 || strcmp(service->uuid(), "1801") == 0) {
        continue; // skip
      }

      sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY, &nordicUUID, &handle);

      lastService = service;
    } else if (localAttribute->type() == BLETypeCharacteristic) {
      BLECharacteristic *characteristic = (BLECharacteristic *)localAttribute;

      if (strcmp(characteristic->uuid(), "2a00") == 0) {
        ble_gap_conn_sec_mode_t secMode;
        BLE_GAP_CONN_SEC_MODE_SET_OPEN(&secMode); // no security is needed

        sd_ble_gap_device_name_set(&secMode, characteristic->value(), characteristic->valueLength());
      } else if (strcmp(characteristic->uuid(), "2a01") == 0) {
        const uint16_t *appearance = (const uint16_t*)characteristic->value();

        sd_ble_gap_appearance_set(*appearance);
      } else if (strcmp(characteristic->uuid(), "2a05") == 0) {
        // do nothing
      } else {
        uint8_t properties = characteristic->properties() & 0xfe;
        uint16_t valueLength = characteristic->valueLength();

        this->_localCharacteristicInfo[localCharacteristicIndex].characteristic = characteristic;
        this->_localCharacteristicInfo[localCharacteristicIndex].notifySubscribed = false;
        this->_localCharacteristicInfo[localCharacteristicIndex].indicateSubscribed = false;
        this->_localCharacteristicInfo[localCharacteristicIndex].service = lastService;

        ble_gatts_char_md_t characteristicMetaData;
        ble_gatts_attr_md_t clientCharacteristicConfigurationMetaData;
        ble_gatts_attr_t    characteristicValueAttribute;
        ble_gatts_attr_md_t characteristicValueAttributeMetaData;

        memset(&characteristicMetaData, 0, sizeof(characteristicMetaData));

        memcpy(&characteristicMetaData.char_props, &properties, 1);

        characteristicMetaData.p_char_user_desc  = NULL;
        characteristicMetaData.p_char_pf         = NULL;
        characteristicMetaData.p_user_desc_md    = NULL;
        characteristicMetaData.p_cccd_md         = NULL;
        characteristicMetaData.p_sccd_md         = NULL;

        if (properties & (BLENotify | BLEIndicate)) {
          memset(&clientCharacteristicConfigurationMetaData, 0, sizeof(clientCharacteristicConfigurationMetaData));

          BLE_GAP_CONN_SEC_MODE_SET_OPEN(&clientCharacteristicConfigurationMetaData.read_perm);
          BLE_GAP_CONN_SEC_MODE_SET_OPEN(&clientCharacteristicConfigurationMetaData.write_perm);

          clientCharacteristicConfigurationMetaData.vloc = BLE_GATTS_VLOC_STACK;

          characteristicMetaData.p_cccd_md = &clientCharacteristicConfigurationMetaData;
        }

        memset(&characteristicValueAttributeMetaData, 0, sizeof(characteristicValueAttributeMetaData));

        if (properties & (BLERead | BLENotify | BLEIndicate)) {
          if (this->_bondStore) {
            BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&characteristicValueAttributeMetaData.read_perm);
          } else {
            BLE_GAP_CONN_SEC_MODE_SET_OPEN(&characteristicValueAttributeMetaData.read_perm);
          }
        }

        if (properties & (BLEWriteWithoutResponse | BLEWrite)) {
          if (this->_bondStore) {
            BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&characteristicValueAttributeMetaData.write_perm);
          } else {
            BLE_GAP_CONN_SEC_MODE_SET_OPEN(&characteristicValueAttributeMetaData.write_perm);
          }
        }

        characteristicValueAttributeMetaData.vloc       = BLE_GATTS_VLOC_STACK;
        characteristicValueAttributeMetaData.rd_auth    = 0;
        characteristicValueAttributeMetaData.wr_auth    = 0;
        characteristicValueAttributeMetaData.vlen       = !characteristic->fixedLength();

        for (int j = (i + 1); j < numLocalAttributes; j++) {
          localAttribute = localAttributes[j];

          if (localAttribute->type() != BLETypeDescriptor) {
            break;
          }

          BLEDescriptor *descriptor = (BLEDescriptor *)localAttribute;

          if (strcmp(descriptor->uuid(), "2901") == 0) {
            characteristicMetaData.p_char_user_desc        = (uint8_t*)descriptor->value();
            characteristicMetaData.char_user_desc_max_size = descriptor->valueLength();
            characteristicMetaData.char_user_desc_size     = descriptor->valueLength();
          } else if (strcmp(descriptor->uuid(), "2904") == 0) {
            characteristicMetaData.p_char_pf = (ble_gatts_char_pf_t *)descriptor->value();
          }
        }

        memset(&characteristicValueAttribute, 0, sizeof(characteristicValueAttribute));

        characteristicValueAttribute.p_uuid       = &nordicUUID;
        characteristicValueAttribute.p_attr_md    = &characteristicValueAttributeMetaData;
        characteristicValueAttribute.init_len     = valueLength;
        characteristicValueAttribute.init_offs    = 0;
        characteristicValueAttribute.max_len      = characteristic->valueSize();
        characteristicValueAttribute.p_value      = NULL;

        sd_ble_gatts_characteristic_add(BLE_GATT_HANDLE_INVALID, &characteristicMetaData, &characteristicValueAttribute, &this->_localCharacteristicInfo[localCharacteristicIndex].handles);

        if (valueLength) {
          for (int j = 0; j < valueLength; j++) {
            value[j] = (*characteristic)[j];
          }

          sd_ble_gatts_value_set(this->_localCharacteristicInfo[localCharacteristicIndex].handles.value_handle, 0, &valueLength, value);
        }

        localCharacteristicIndex++;
      }
    } else if (localAttribute->type() == BLETypeDescriptor) {
      BLEDescriptor *descriptor = (BLEDescriptor *)localAttribute;

      if (strcmp(descriptor->uuid(), "2901") == 0 ||
          strcmp(descriptor->uuid(), "2902") == 0 ||
          strcmp(descriptor->uuid(), "2903") == 0 ||
          strcmp(descriptor->uuid(), "2904") == 0) {
        continue; // skip
      }

      uint16_t valueLength = descriptor->valueLength();

      ble_gatts_attr_t descriptorAttribute;
      ble_gatts_attr_md_t descriptorMetaData;

      memset(&descriptorAttribute, 0, sizeof(descriptorAttribute));
      memset(&descriptorMetaData, 0, sizeof(descriptorMetaData));

      descriptorMetaData.vloc = BLE_GATTS_VLOC_STACK;
      descriptorMetaData.vlen = (valueLength == descriptor->valueLength()) ? 0 : 1;

      if (this->_bondStore) {
        BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&descriptorMetaData.read_perm);
      } else {
        BLE_GAP_CONN_SEC_MODE_SET_OPEN(&descriptorMetaData.read_perm);
      }

      descriptorAttribute.p_uuid    = &nordicUUID;
      descriptorAttribute.p_attr_md = &descriptorMetaData;
      descriptorAttribute.init_len  = valueLength;
      descriptorAttribute.max_len   = descriptor->valueLength();
      descriptorAttribute.p_value   = NULL;

      sd_ble_gatts_descriptor_add(BLE_GATT_HANDLE_INVALID, &descriptorAttribute, &handle);

      if (valueLength) {
        for (int j = 0; j < valueLength; j++) {
          value[j] = (*descriptor)[j];
        }

        sd_ble_gatts_value_set(handle, 0, &valueLength, value);
      }
    }
  }

  if ( numRemoteAttributes > 0) {
    numRemoteAttributes -= 2; // 0x1801, 0x2a05
  }

  for (int i = 0; i < numRemoteAttributes; i++) {
    BLERemoteAttribute *remoteAttribute = remoteAttributes[i];

    if (remoteAttribute->type() == BLETypeService) {
      this->_numRemoteServices++;
    } else if (remoteAttribute->type() == BLETypeCharacteristic) {
      this->_numRemoteCharacteristics++;
    }
  }

  this->_remoteServiceInfo = (struct remoteServiceInfo*)malloc(sizeof(struct remoteServiceInfo) * this->_numRemoteServices);
  this->_remoteCharacteristicInfo = (struct remoteCharacteristicInfo*)malloc(sizeof(struct remoteCharacteristicInfo) * this->_numRemoteCharacteristics);

  BLERemoteService *lastRemoteService = NULL;
  unsigned char remoteServiceIndex = 0;
  unsigned char remoteCharacteristicIndex = 0;

  for (int i = 0; i < numRemoteAttributes; i++) {
    BLERemoteAttribute *remoteAttribute = remoteAttributes[i];
    BLEUuid uuid = BLEUuid(remoteAttribute->uuid());
    const unsigned char* uuidData = uuid.data();

    ble_uuid_t nordicUUID;

    if (uuid.length() == 2) {
      nordicUUID.uuid = (uuidData[1] << 8) | uuidData[0];
      nordicUUID.type = BLE_UUID_TYPE_BLE;
    } else {
      unsigned char uuidDataTemp[16];

      memcpy(&uuidDataTemp, uuidData, sizeof(uuidDataTemp));

      nordicUUID.uuid = (uuidData[13] << 8) | uuidData[12];

      uuidDataTemp[13] = 0;
      uuidDataTemp[12] = 0;

      sd_ble_uuid_vs_add((ble_uuid128_t*)&uuidDataTemp, &nordicUUID.type);
    }

    if (remoteAttribute->type() == BLETypeService) {
      this->_remoteServiceInfo[remoteServiceIndex].service = lastRemoteService = (BLERemoteService *)remoteAttribute;
      this->_remoteServiceInfo[remoteServiceIndex].uuid = nordicUUID;

      memset(&this->_remoteServiceInfo[remoteServiceIndex].handlesRange, 0, sizeof(this->_remoteServiceInfo[remoteServiceIndex].handlesRange));

      remoteServiceIndex++;
    } else if (remoteAttribute->type() == BLETypeCharacteristic) {
      this->_remoteCharacteristicInfo[remoteCharacteristicIndex].characteristic = (BLERemoteCharacteristic *)remoteAttribute;
      this->_remoteCharacteristicInfo[remoteCharacteristicIndex].service = lastRemoteService;
      this->_remoteCharacteristicInfo[remoteCharacteristicIndex].uuid = nordicUUID;

      memset(&this->_remoteCharacteristicInfo[remoteCharacteristicIndex].properties, 0, sizeof(this->_remoteCharacteristicInfo[remoteCharacteristicIndex].properties));
      this->_remoteCharacteristicInfo[remoteCharacteristicIndex].valueHandle = 0;

      remoteCharacteristicIndex++;
    }
  }

  if (this->_bondStore && this->_bondStore->hasData()) {
#ifdef NRF_51822_DEBUG
    //Serial.println(F("Restoring bond data"));
    BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] Restoring bond data\n");
#endif
#if defined(NRF5) || defined(NRF51_S130)
    this->_bondStore->getData(this->_bondData, 0, sizeof(this->_bondData));
#else
    this->_bondStore->getData(this->_authStatusBuffer, 0, sizeof(this->_authStatusBuffer));
#endif
  }

  /* add by Ebony */
  if (_gapAddress.addr_type!=0xFF)
  {


#ifdef NRF_51822_DEBUG


	  //Serial.print("gap addr ");
	  //Serial.println(_gapAddress.addr[0]);
	  BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] Gap addr:%02X%02X%02X%02X%02X%02X\n",
			  _gapAddress.addr[5],_gapAddress.addr[4],_gapAddress.addr[3],
			  _gapAddress.addr[2],_gapAddress.addr[1],_gapAddress.addr[0]);
#endif

	  // Brickcom changed.
#if (NRF_SD_BLE_API_VERSION == 2)
	  sd_ble_gap_address_set(BLE_GAP_ADDR_CYCLE_MODE_NONE,&_gapAddress);
#else

	  #ifdef NRF51
	  sd_ble_gap_address_set(BLE_GAP_ADDR_CYCLE_MODE_NONE, &_gapAddress);
	  #elif NRF52
	  sd_ble_gap_addr_set(&_gapAddress);
	  #else
	  #endif
#endif

  }
  /* add by Ebony */

  this->startAdvertising();

#ifdef __RFduino__
  RFduinoBLE_enabled = 1;
#endif
}


bool nRF51822::startScanning(ble_scan_response_handler_t scanResponseHandler) {
	_scanResponseHandler = scanResponseHandler;
	uint32_t err_code = sd_ble_gap_scan_start(&scan_params);
	return err_code == NRF_SUCCESS; // true if OK
}

bool nRF51822::stopScanning() {
	uint32_t err_code = sd_ble_gap_scan_stop();
	return err_code == NRF_SUCCESS; // true if OK
}

bool nRF51822::poll() {
  uint32_t   evtBuf[BLE_STACK_EVT_MSG_BUF_SIZE] __attribute__ ((__aligned__(BLE_EVTS_PTR_ALIGNMENT)));
  uint16_t   evtLen = sizeof(evtBuf);
  ble_evt_t* bleEvt = (ble_evt_t*)evtBuf;
  bool rtn = false;
  if (sd_ble_evt_get((uint8_t*)evtBuf, &evtLen) == NRF_SUCCESS) {
  	rtn = true; // found one
    switch (bleEvt->header.evt_id) {
#if !defined(BLE_EVT_TX_COMPLETE)
#define BLE_EVT_TX_COMPLETE  BLE_EVT_USER_MEM_REQUEST
#endif
      case BLE_EVT_TX_COMPLETE:
#ifdef NRF_51822_DEBUG
        //Serial.print(F("Evt TX complete "));
        BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] Evt TX complete\n");
        //Serial.println(bleEvt->evt.common_evt.params.tx_complete.count);
#endif

#if (NRF_SD_BLE_API_VERSION >= 5)
        this->_txBufferCount += bleEvt->evt.gatts_evt.params.hvn_tx_complete.count;
#else
        this->_txBufferCount += bleEvt->evt.common_evt.params.tx_complete.count;
#endif

        break;

       case BLE_GAP_EVT_ADV_REPORT: {
/**********       		   
typedef struct
{
  ble_evt_hdr_t header;           /**< Event header. 
  union
  {
    ble_common_evt_t  common_evt; /**< Common Event, evt_id in BLE_EVT_* series. 
    ble_gap_evt_t     gap_evt;    /**< GAP originated event, evt_id in BLE_GAP_EVT_* series. 
    ble_l2cap_evt_t   l2cap_evt;  /**< L2CAP originated event, evt_id in BLE_L2CAP_EVT* series. 
    ble_gattc_evt_t   gattc_evt;  /**< GATT client originated event, evt_id in BLE_GATTC_EVT* series. 
    ble_gatts_evt_t   gatts_evt;  /**< GATT server originated event, evt_id in BLE_GATTS_EVT* series. 
  } evt;
} ble_evt_t;

/** GAP event structure. 
typedef struct
{
  uint16_t conn_handle;                                     /**< Connection Handle on which event occurred. 
  union                                                     /**< union alternative identified by evt_id in enclosing struct. 
  {
    ble_gap_evt_connected_t                   connected;                    /**< Connected Event Parameters. 
    ble_gap_evt_disconnected_t                disconnected;                 /**< Disconnected Event Parameters. 
    ble_gap_evt_conn_param_update_t           conn_param_update;            /**< Connection Parameter Update Parameters. 
    ble_gap_evt_sec_params_request_t          sec_params_request;           /**< Security Parameters Request Event Parameters. 
    ble_gap_evt_sec_info_request_t            sec_info_request;             /**< Security Information Request Event Parameters. 
    ble_gap_evt_passkey_display_t             passkey_display;              /**< Passkey Display Event Parameters. 
    ble_gap_evt_key_pressed_t                 key_pressed;                  /**< Key Pressed Event Parameters. 
    ble_gap_evt_auth_key_request_t            auth_key_request;             /**< Authentication Key Request Event Parameters. 
    ble_gap_evt_lesc_dhkey_request_t          lesc_dhkey_request;           /**< LE Secure Connections DHKey calculation request. 
    ble_gap_evt_auth_status_t                 auth_status;                  /**< Authentication Status Event Parameters. 
    ble_gap_evt_conn_sec_update_t             conn_sec_update;              /**< Connection Security Update Event Parameters. 
    ble_gap_evt_timeout_t                     timeout;                      /**< Timeout Event Parameters. 
    ble_gap_evt_rssi_changed_t                rssi_changed;                 /**< RSSI Event parameters. 
    ble_gap_evt_adv_report_t                  adv_report;                   /**< Advertising Report Event Parameters. 
    ble_gap_evt_sec_request_t                 sec_request;                  /**< Security Request Event Parameters. 
    ble_gap_evt_conn_param_update_request_t   conn_param_update_request;    /**< Connection Parameter Update Parameters. 
    ble_gap_evt_scan_req_report_t             scan_req_report;              /**< Scan Request Report parameters. 
  } params;                                                                 /**< Event Parameters. 

} ble_gap_evt_t;

   typedef struct {
  ble_gap_addr_t peer_addr;                     /**< Bluetooth address of the peer device. 
  int8_t         rssi;                          /**< Received Signal Strength Indication in dBm. 
  uint8_t        scan_rsp : 1;                  /**< If 1, the report corresponds to a scan response and the type field may be ignored.
  uint8_t        type     : 2;                  /**< See @ref BLE_GAP_ADV_TYPES. Only valid if the scan_rsp field is 0. 
  uint8_t        dlen     : 5;                  /**< Advertising or scan response data length. 
  uint8_t        data[BLE_GAP_ADV_MAX_SIZE];    /**< Advertising or scan response data. 
} ble_gap_evt_adv_report_t;

typedef struct {
  uint8_t addr_id_peer : 1;       /**< Only valid for peer addresses.
                                       This bit is set by the SoftDevice to indicate whether the address has been resolved from
                                       a Resolvable Private Address (when the peer is using privacy).
                                       If set to 1, @ref addr and @ref addr_type refer to the identity address of the resolved address.

                                       This bit is ignored when a variable of type @ref ble_gap_addr_t is used as input to API functions. 
  uint8_t addr_type    : 7;       /**< See @ref BLE_GAP_ADDR_TYPES. 
  uint8_t addr[BLE_GAP_ADDR_LEN]; /**< 48-bit address, LSB format.
                                       @ref addr is not used if @ref addr_type is @ref BLE_GAP_ADDR_TYPE_ANONYMOUS. 
} ble_gap_addr_t;

BLE address length.
#define BLE_GAP_ADDR_LEN (6)
#define  BLE_GAP_ADV_MAX_SIZE           31

/** BLE_GAP_ADV_TYPES GAP Advertising types
#define BLE_GAP_ADV_TYPE_ADV_IND          0x00   /**< Connectable undirected. 
#define BLE_GAP_ADV_TYPE_ADV_DIRECT_IND   0x01   /**< Connectable directed. 
#define BLE_GAP_ADV_TYPE_ADV_SCAN_IND     0x02   /**< Scannable undirected. 
#define BLE_GAP_ADV_TYPE_ADV_NONCONN_IND  0x03   /**< Non connectable undirected. 
**********/

         ble_gap_evt_t * p_gap_evt = &(bleEvt->evt.gap_evt);
         ble_gap_evt_adv_report_t *p_adv_report = &(p_gap_evt->params.adv_report);
         //ble_gap_evt_adv_report_t const * p_adv_report = &bleEvt->evt.gap_evt.params.adv_report;
         uint8_t scan_response_type = p_adv_report->scan_rsp;
         uint8_t _len = p_adv_report->dlen;
         uint8_t *_data = p_adv_report->data;
#ifdef NRF_51822_DEBUG
         if (scan_response_type) {
                if (_len > 0) {
                    Serial.print("[ble] Scan response received:");
                    BLEUtil::printBuffer(&Serial,_data, _len);
                } else {
                    Serial.print("[ble] Empty scan response received.");
                }
         } else {
                Serial.print("[ble] Advertising packet received:");
                BLEUtil::printBuffer(&Serial,_data, _len);
         }
#endif         
         if (this->_scanResponseHandler != NULL) {
#ifdef NRF_51822_DEBUG
             Serial.println("[ble] Call handler");
#endif         
             this->_scanResponseHandler(p_adv_report);
         }
          // Continue scanning.
          //sd_ble_gap_scan_start(NULL, &m_scan_buffer);
          break;
       }
       
      case BLE_GAP_EVT_CONNECTED: {

#ifdef NRF_51822_DEBUG
        char address[18];
        BLEUtil::addressToString(bleEvt->evt.gap_evt.params.connected.peer_addr.addr, address);
        Serial.print(F("[ble] Evt Connected "));
        Serial.println(address);

#endif

        this->_connectionHandle = bleEvt->evt.gap_evt.conn_handle;

#if defined(NRF5) && !defined(S110)
        {
          uint8_t count;

#if (NRF_SD_BLE_API_VERSION == 2)
          sd_ble_tx_packet_count_get(this->_connectionHandle, &count);
#endif          

          this->_txBufferCount = count;
        }
#else
        sd_ble_tx_buffer_count_get(&this->_txBufferCount);
#endif

        if (this->_eventListener) {
          this->_eventListener->BLEDeviceConnected(*this, bleEvt->evt.gap_evt.params.connected.peer_addr.addr);
        }
        // note this case is inside a { } block
  	  	unsigned short minConInterval = (this->_minimumConnectionInterval * 8) /10;  // in 1.25ms units
        unsigned short maxConInterval = (this->_maximumConnectionInterval * 8) /10;  // in 1.25ms units

        if ((minConInterval >= BLE_GAP_CP_MIN_CONN_INTVL_MIN) &&
            (maxConInterval <= BLE_GAP_CP_MAX_CONN_INTVL_MAX)) {

          ble_gap_conn_params_t gap_conn_params;
          
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] minConInterval: ")); Serial.print(minConInterval);
        Serial.print(F("[ble] maxConInterval: ")); Serial.print(maxConInterval);
        Serial.println();
#endif
          // check slaveLatency
          int latency = this->_slaveLatency;
          int maxLatency = ((int)DEFAULT_CONNECTION_SUPERVISION_TIMEOUT_ms) / ((int)this->_maximumConnectionInterval) -1;
          if (latency > maxLatency) {
          	  latency = maxLatency -1 ;
          }
          if (latency < 0) {
          	  latency = 0;
          }
          this->_slaveLatency = latency;
          gap_conn_params.min_conn_interval = minConInterval;  // in 1.25ms units
          gap_conn_params.max_conn_interval = maxConInterval;  // in 1.25ms units
          gap_conn_params.slave_latency     = this->_slaveLatency;
          gap_conn_params.conn_sup_timeout  = DEFAULT_CONNECTION_SUPERVISION_TIMEOUT_ms / 10; // in 10ms unit

          sd_ble_gap_conn_param_update(this->_connectionHandle, &gap_conn_params);
        }

        if (this->_numRemoteServices > 0) {
          sd_ble_gattc_primary_services_discover(this->_connectionHandle, 1, NULL);
        }
        break;
      }
      case BLE_GAP_EVT_DISCONNECTED:
#ifdef NRF_51822_DEBUG
        Serial.println(F("[ble] Evt Disconnected"));
#endif
        this->_connectionHandle = BLE_CONN_HANDLE_INVALID;
        this->_txBufferCount = 0;

        for (int i = 0; i < this->_numLocalCharacteristics; i++) {
          struct localCharacteristicInfo* localCharacteristicInfo = &this->_localCharacteristicInfo[i];

          localCharacteristicInfo->notifySubscribed = false;
          localCharacteristicInfo->indicateSubscribed = false;

          if (localCharacteristicInfo->characteristic->subscribed()) {
            if (this->_eventListener) {
              this->_eventListener->BLEDeviceCharacteristicSubscribedChanged(*this, *localCharacteristicInfo->characteristic, false);
            }
          }
        }

        if (this->_eventListener) {
          this->_eventListener->BLEDeviceDisconnected(*this);
        }

        // clear remote handle info
        for (int i = 0; i < this->_numRemoteServices; i++) {
          memset(&this->_remoteServiceInfo[i].handlesRange, 0, sizeof(this->_remoteServiceInfo[i].handlesRange));
        }

        for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
          memset(&this->_remoteCharacteristicInfo[i].properties, 0, sizeof(this->_remoteCharacteristicInfo[i].properties));
          this->_remoteCharacteristicInfo[i].valueHandle = 0;
        }

        this->_remoteRequestInProgress = false;

        this->startAdvertising();
        break;

      case BLE_GAP_EVT_CONN_PARAM_UPDATE:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Conn Param Update 0x"));
        Serial.print(bleEvt->evt.gap_evt.params.conn_param_update.conn_params.min_conn_interval, HEX);
        Serial.print(F(" 0x"));
        Serial.print(bleEvt->evt.gap_evt.params.conn_param_update.conn_params.max_conn_interval, HEX);
        Serial.print(F(" 0x"));
        Serial.print(bleEvt->evt.gap_evt.params.conn_param_update.conn_params.slave_latency, HEX);
        Serial.print(F(" 0x"));
        Serial.print(bleEvt->evt.gap_evt.params.conn_param_update.conn_params.conn_sup_timeout, HEX);
        Serial.println();
#endif
        break;

      case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Sec Params Request "));
#if !defined(NRF5) && !defined(NRF51_S130)
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.timeout);
        Serial.print(F(" "));
#endif
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.bond);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.mitm);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.io_caps);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.oob);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.min_key_size);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_params_request.peer_params.max_key_size);
        Serial.println();
#endif

        if (this->_bondStore && !this->_bondStore->hasData()) {
          // only allow bonding if bond store exists and there is no data

          ble_gap_sec_params_t gapSecParams;

          memset(&gapSecParams, 0x00, sizeof(ble_gap_sec_params_t));

#if defined(NRF5) && !defined(S110)
          gapSecParams.kdist_own.enc = 1;
#elif defined(NRF51_S130)
          gapSecParams.kdist_periph.enc = 1;
#elif !defined(NRF5)
          gapSecParams.timeout          = 30; // must be 30s
#endif
          gapSecParams.bond             = true;
          gapSecParams.mitm             = false;
          gapSecParams.io_caps          = BLE_GAP_IO_CAPS_NONE;
          gapSecParams.oob              = false;
          gapSecParams.min_key_size     = 7;
          gapSecParams.max_key_size     = 16;

#if defined(NRF5) && !defined(S110)
          ble_gap_sec_keyset_t keyset;

          keyset.keys_peer.p_enc_key  = NULL;
          keyset.keys_peer.p_id_key   = NULL;
          keyset.keys_peer.p_sign_key = NULL;
          keyset.keys_own.p_enc_key   = this->_encKey;
          keyset.keys_own.p_id_key    = NULL;
          keyset.keys_own.p_sign_key  = NULL;

          sd_ble_gap_sec_params_reply(this->_connectionHandle, BLE_GAP_SEC_STATUS_SUCCESS, &gapSecParams, &keyset);
#elif defined(NRF51_S130) || defined(S110)
          ble_gap_sec_keyset_t keyset;

          keyset.keys_central.p_enc_key  = NULL;
          keyset.keys_central.p_id_key   = NULL;
          keyset.keys_central.p_sign_key = NULL;
          keyset.keys_periph.p_enc_key   = this->_encKey;
          keyset.keys_periph.p_id_key    = NULL;
          keyset.keys_periph.p_sign_key  = NULL;

          sd_ble_gap_sec_params_reply(this->_connectionHandle, BLE_GAP_SEC_STATUS_SUCCESS, &gapSecParams, &keyset);
#else
          sd_ble_gap_sec_params_reply(this->_connectionHandle, BLE_GAP_SEC_STATUS_SUCCESS, &gapSecParams);
#endif
        } else {
#if defined(NRF5) || defined(NRF51_S130)
          sd_ble_gap_sec_params_reply(this->_connectionHandle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL, NULL);
#else
          sd_ble_gap_sec_params_reply(this->_connectionHandle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL);
#endif
        }
        break;

      case BLE_GAP_EVT_SEC_INFO_REQUEST:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Sec Info Request "));
        // Serial.print(bleEvt->evt.gap_evt.params.sec_info_request.peer_addr);
        // Serial.print(F(" "));
#if defined(NRF5) || defined(NRF51_S130)
        Serial.print(bleEvt->evt.gap_evt.params.sec_info_request.master_id.ediv);
#else
        Serial.print(bleEvt->evt.gap_evt.params.sec_info_request.div);
#endif
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_info_request.enc_info);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_info_request.id_info);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.sec_info_request.sign_info);
        Serial.println();
#endif
#if defined(NRF5) || defined(NRF51_S130)
        if (this->_encKey->master_id.ediv == bleEvt->evt.gap_evt.params.sec_info_request.master_id.ediv) {
          sd_ble_gap_sec_info_reply(this->_connectionHandle, &this->_encKey->enc_info, NULL, NULL);
        } else {
          sd_ble_gap_sec_info_reply(this->_connectionHandle, NULL, NULL, NULL);
        }
#else
        if (this->_authStatus->periph_keys.enc_info.div == bleEvt->evt.gap_evt.params.sec_info_request.div) {
          sd_ble_gap_sec_info_reply(this->_connectionHandle, &this->_authStatus->periph_keys.enc_info, NULL);
        } else {
          sd_ble_gap_sec_info_reply(this->_connectionHandle, NULL, NULL);
        }
#endif
        break;

      case BLE_GAP_EVT_AUTH_STATUS:
#ifdef NRF_51822_DEBUG
        Serial.println(F("[ble] Evt Auth Status"));
        Serial.println(bleEvt->evt.gap_evt.params.auth_status.auth_status);
#endif
        if (BLE_GAP_SEC_STATUS_SUCCESS == bleEvt->evt.gap_evt.params.auth_status.auth_status) {
#if !defined(NRF5) && !defined(NRF51_S130)
          *this->_authStatus = bleEvt->evt.gap_evt.params.auth_status;
#endif
          if (this->_bondStore) {
#ifdef NRF_51822_DEBUG
            Serial.println(F("[ble] Storing bond data"));
#endif
#if defined(NRF5) || defined(NRF51_S130)
            this->_bondStore->putData(this->_bondData, 0, sizeof(this->_bondData));
#else
            this->_bondStore->putData(this->_authStatusBuffer, 0, sizeof(this->_authStatusBuffer));
#endif
          }

          if (this->_eventListener) {
            this->_eventListener->BLEDeviceBonded(*this);
          }
        }
        break;

      case BLE_GAP_EVT_CONN_SEC_UPDATE:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Conn Sec Update "));
        Serial.print(bleEvt->evt.gap_evt.params.conn_sec_update.conn_sec.sec_mode.sm);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.conn_sec_update.conn_sec.sec_mode.lv);
        Serial.print(F(" "));
        Serial.print(bleEvt->evt.gap_evt.params.conn_sec_update.conn_sec.encr_key_size);
        Serial.println();
#endif
        break;

      case BLE_GATTS_EVT_WRITE: {
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Write, handle = "));
        Serial.println(bleEvt->evt.gatts_evt.params.write.handle, DEC);

        BLEUtil::printBuffer(&Serial,bleEvt->evt.gatts_evt.params.write.data, bleEvt->evt.gatts_evt.params.write.len);
#endif

        uint16_t handle = bleEvt->evt.gatts_evt.params.write.handle;

        for (int i = 0; i < this->_numLocalCharacteristics; i++) {
          struct localCharacteristicInfo* localCharacteristicInfo = &this->_localCharacteristicInfo[i];

          if (localCharacteristicInfo->handles.value_handle == handle) {
            if (this->_eventListener) {
              this->_eventListener->BLEDeviceCharacteristicValueChanged(*this, *localCharacteristicInfo->characteristic, bleEvt->evt.gatts_evt.params.write.data, bleEvt->evt.gatts_evt.params.write.len);
            }
            break;
          } else if (localCharacteristicInfo->handles.cccd_handle == handle) {
            uint8_t* data  = &bleEvt->evt.gatts_evt.params.write.data[0];
            uint16_t value = data[0] | (data[1] << 8);

            localCharacteristicInfo->notifySubscribed = (value & 0x0001);
            localCharacteristicInfo->indicateSubscribed = (value & 0x0002);

            bool subscribed = (localCharacteristicInfo->notifySubscribed || localCharacteristicInfo->indicateSubscribed);

            if (subscribed != localCharacteristicInfo->characteristic->subscribed()) {
              if (this->_eventListener) {
                this->_eventListener->BLEDeviceCharacteristicSubscribedChanged(*this, *localCharacteristicInfo->characteristic, subscribed);
              }
              break;
            }
          }
        }
        break;
      }

      case BLE_GATTS_EVT_SYS_ATTR_MISSING:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Sys Attr Missing "));
        Serial.println(bleEvt->evt.gatts_evt.params.sys_attr_missing.hint);
#endif
#if defined(NRF5) || defined(NRF51_S130)
        sd_ble_gatts_sys_attr_set(this->_connectionHandle, NULL, 0, 0);
#else
        sd_ble_gatts_sys_attr_set(this->_connectionHandle, NULL, 0);
#endif
        break;

      case BLE_GATTC_EVT_PRIM_SRVC_DISC_RSP:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Prim Srvc Disc Rsp 0x"));
        Serial.println(bleEvt->evt.gattc_evt.gatt_status, HEX);
#endif
        if (bleEvt->evt.gattc_evt.gatt_status == BLE_GATT_STATUS_SUCCESS) {
          uint16_t count = bleEvt->evt.gattc_evt.params.prim_srvc_disc_rsp.count;
          for (int i = 0; i < count; i++) {
            for (int j = 0; j < this->_numRemoteServices; j++) {
              if ((bleEvt->evt.gattc_evt.params.prim_srvc_disc_rsp.services[i].uuid.type == this->_remoteServiceInfo[j].uuid.type) &&
                  (bleEvt->evt.gattc_evt.params.prim_srvc_disc_rsp.services[i].uuid.uuid == this->_remoteServiceInfo[j].uuid.uuid)) {
                this->_remoteServiceInfo[j].handlesRange = bleEvt->evt.gattc_evt.params.prim_srvc_disc_rsp.services[i].handle_range;
                break;
              }
            }
          }

          uint16_t startHandle = bleEvt->evt.gattc_evt.params.prim_srvc_disc_rsp.services[count - 1].handle_range.end_handle + 1;

          sd_ble_gattc_primary_services_discover(this->_connectionHandle, startHandle, NULL);
        } else {
          // done discovering services
          for (int i = 0; i < this->_numRemoteServices; i++) {
            if (this->_remoteServiceInfo[i].handlesRange.start_handle != 0 && this->_remoteServiceInfo[i].handlesRange.end_handle != 0) {
              this->_remoteServiceDiscoveryIndex = i;

              sd_ble_gattc_characteristics_discover(this->_connectionHandle, &this->_remoteServiceInfo[i].handlesRange);
              break;
            }
          }
        }
        break;

      case BLE_GATTC_EVT_CHAR_DISC_RSP:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Char Disc Rsp 0x"));
        Serial.println(bleEvt->evt.gattc_evt.gatt_status, HEX);
#endif
        if (bleEvt->evt.gattc_evt.gatt_status == BLE_GATT_STATUS_SUCCESS) {
          ble_gattc_handle_range_t serviceHandlesRange = this->_remoteServiceInfo[this->_remoteServiceDiscoveryIndex].handlesRange;

          uint16_t count = bleEvt->evt.gattc_evt.params.char_disc_rsp.count;

          for (int i = 0; i < count; i++) {
            for (int j = 0; j < this->_numRemoteCharacteristics; j++) {
              if ((this->_remoteServiceInfo[this->_remoteServiceDiscoveryIndex].service == this->_remoteCharacteristicInfo[j].service) &&
                  (bleEvt->evt.gattc_evt.params.char_disc_rsp.chars[i].uuid.type == this->_remoteCharacteristicInfo[j].uuid.type) &&
                  (bleEvt->evt.gattc_evt.params.char_disc_rsp.chars[i].uuid.uuid == this->_remoteCharacteristicInfo[j].uuid.uuid)) {
                this->_remoteCharacteristicInfo[j].properties = bleEvt->evt.gattc_evt.params.char_disc_rsp.chars[i].char_props;
                this->_remoteCharacteristicInfo[j].valueHandle = bleEvt->evt.gattc_evt.params.char_disc_rsp.chars[i].handle_value;
              }
            }

            serviceHandlesRange.start_handle = bleEvt->evt.gattc_evt.params.char_disc_rsp.chars[i].handle_value;
          }

          sd_ble_gattc_characteristics_discover(this->_connectionHandle, &serviceHandlesRange);
        } else {
          bool discoverCharacteristics = false;

          for (int i = this->_remoteServiceDiscoveryIndex + 1; i < this->_numRemoteServices; i++) {
            if (this->_remoteServiceInfo[i].handlesRange.start_handle != 0 && this->_remoteServiceInfo[i].handlesRange.end_handle != 0) {
              this->_remoteServiceDiscoveryIndex = i;

              sd_ble_gattc_characteristics_discover(this->_connectionHandle, &this->_remoteServiceInfo[i].handlesRange);
              discoverCharacteristics = true;
              break;
            }
          }

          if (!discoverCharacteristics) {
            if (this->_eventListener) {
              this->_eventListener->BLEDeviceRemoteServicesDiscovered(*this);
            }
          }
        }
        break;

      case BLE_GATTC_EVT_READ_RSP: {
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Read Rsp 0x"));
        Serial.println(bleEvt->evt.gattc_evt.gatt_status, HEX);
        Serial.println(bleEvt->evt.gattc_evt.params.read_rsp.handle, DEC);
        BLEUtil::printBuffer(&Serial,bleEvt->evt.gattc_evt.params.read_rsp.data, bleEvt->evt.gattc_evt.params.read_rsp.len);
#endif
        this->_remoteRequestInProgress = false;

        if (bleEvt->evt.gattc_evt.gatt_status == BLE_GATT_STATUS_ATTERR_INSUF_AUTHENTICATION &&
            this->_bondStore) {
          ble_gap_sec_params_t gapSecParams;

          memset(&gapSecParams, 0x00, sizeof(ble_gap_sec_params_t));

#if defined(NRF5) && !defined(S110)
          gapSecParams.kdist_own.enc = 1;
#elif defined(NRF51_S130)
          gapSecParams.kdist_periph.enc = 1;
#elif !defined(NRF5)
          gapSecParams.timeout          = 30; // must be 30s
#endif
          gapSecParams.bond             = true;
          gapSecParams.mitm             = false;
          gapSecParams.io_caps          = BLE_GAP_IO_CAPS_NONE;
          gapSecParams.oob              = false;
          gapSecParams.min_key_size     = 7;
          gapSecParams.max_key_size     = 16;

          sd_ble_gap_authenticate(this->_connectionHandle, &gapSecParams);
        } else {
          uint16_t handle = bleEvt->evt.gattc_evt.params.read_rsp.handle;

          for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
            if (this->_remoteCharacteristicInfo[i].valueHandle == handle) {
              if (this->_eventListener) {
                this->_eventListener->BLEDeviceRemoteCharacteristicValueChanged(*this, *this->_remoteCharacteristicInfo[i].characteristic, bleEvt->evt.gattc_evt.params.read_rsp.data, bleEvt->evt.gattc_evt.params.read_rsp. len);
              }
              break;
            }
          }
        }
        break;
      }

      case BLE_GATTC_EVT_WRITE_RSP:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Write Rsp 0x"));
        Serial.println(bleEvt->evt.gattc_evt.gatt_status, HEX);
        Serial.println(bleEvt->evt.gattc_evt.params.write_rsp.handle, DEC);
#endif
        this->_remoteRequestInProgress = false;

        if (bleEvt->evt.gattc_evt.gatt_status == BLE_GATT_STATUS_ATTERR_INSUF_AUTHENTICATION &&
            this->_bondStore) {
          ble_gap_sec_params_t gapSecParams;

          memset(&gapSecParams, 0x00, sizeof(ble_gap_sec_params_t));

#if defined(NRF5) && !defined(S110)
          gapSecParams.kdist_own.enc = 1;
#elif defined(NRF51_S130)
          gapSecParams.kdist_periph.enc = 1;
#elif !defined(NRF5)
          gapSecParams.timeout          = 30; // must be 30s
#endif
          gapSecParams.bond             = true;
          gapSecParams.mitm             = false;
          gapSecParams.io_caps          = BLE_GAP_IO_CAPS_NONE;
          gapSecParams.oob              = false;
          gapSecParams.min_key_size     = 7;
          gapSecParams.max_key_size     = 16;

          sd_ble_gap_authenticate(this->_connectionHandle, &gapSecParams);
        }
        break;

      case BLE_GATTC_EVT_HVX: {
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] Evt Hvx 0x"));
        Serial.println(bleEvt->evt.gattc_evt.gatt_status, HEX);
        Serial.println(bleEvt->evt.gattc_evt.params.hvx.handle, DEC);
#endif
        uint16_t handle = bleEvt->evt.gattc_evt.params.hvx.handle;

        if (bleEvt->evt.gattc_evt.params.hvx.type == BLE_GATT_HVX_INDICATION) {
          sd_ble_gattc_hv_confirm(this->_connectionHandle, handle);
        }

        for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
          if (this->_remoteCharacteristicInfo[i].valueHandle == handle) {
            if (this->_eventListener) {
              this->_eventListener->BLEDeviceRemoteCharacteristicValueChanged(*this, *this->_remoteCharacteristicInfo[i].characteristic, bleEvt->evt.gattc_evt.params.read_rsp.data, bleEvt->evt.gattc_evt.params.read_rsp. len);
            }
            break;
          }
        }
        break;
      }

      default:
#ifdef NRF_51822_DEBUG
        Serial.print(F("[ble] bleEvt->header.evt_id = 0x"));
        Serial.print(bleEvt->header.evt_id, HEX);
        Serial.print(F(" "));
        Serial.println(bleEvt->header.evt_len);
#endif
        break;
    }
  }
  
  // sd_app_evt_wait();
  return rtn;
}

void nRF51822::end() {
  //sd_softdevice_disable(); keep the LF clock running

  if (this->_remoteCharacteristicInfo) {
    free(this->_remoteCharacteristicInfo);
  }

  if (this->_remoteServiceInfo) {
    free(this->_remoteServiceInfo);
  }

  if (this->_localCharacteristicInfo) {
    free(this->_localCharacteristicInfo);
  }

  this->_numLocalCharacteristics = 0;
  this->_numRemoteServices = 0;
  this->_numRemoteCharacteristics = 0;

  _adv_started = 0;
  sd_ble_gap_adv_stop();
}

bool nRF51822::updateCharacteristicValue(BLECharacteristic& characteristic) {
  bool success = true;

  for (int i = 0; i < this->_numLocalCharacteristics; i++) {
    struct localCharacteristicInfo* localCharacteristicInfo = &this->_localCharacteristicInfo[i];

    if (localCharacteristicInfo->characteristic == &characteristic) {
      if (&characteristic == this->_broadcastCharacteristic) {
        this->broadcastCharacteristic(characteristic);
      }

      uint16_t valueLength = characteristic.valueLength();

      sd_ble_gatts_value_set(localCharacteristicInfo->handles.value_handle, 0, &valueLength, characteristic.value());

      ble_gatts_hvx_params_t hvxParams;

      memset(&hvxParams, 0, sizeof(hvxParams));

      hvxParams.handle = localCharacteristicInfo->handles.value_handle;
      hvxParams.offset = 0;
      hvxParams.p_data = NULL;
      hvxParams.p_len  = &valueLength;

      if (localCharacteristicInfo->notifySubscribed) {
        if (this->_txBufferCount > 0) {
            this->_txBufferCount--;

          hvxParams.type = BLE_GATT_HVX_NOTIFICATION;

          if (sd_ble_gatts_hvx(this->_connectionHandle, &hvxParams) == NRF_SUCCESS) {
            success = true;
          } else {
            success = false;
          }
        } else {
          success = false;
        }
      }

      if (localCharacteristicInfo->indicateSubscribed) {
        if (this->_txBufferCount > 0) {
            this->_txBufferCount--;

          hvxParams.type = BLE_GATT_HVX_INDICATION;

         if (sd_ble_gatts_hvx(this->_connectionHandle, &hvxParams) == NRF_SUCCESS) {
            success = true;
          } else {
            success = false;
          }
        } else {
          success = false;
        }
      }
    }
  }

  return success;
}

bool nRF51822::broadcastCharacteristic(BLECharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numLocalCharacteristics; i++) {
    struct localCharacteristicInfo* localCharacteristicInfo = &this->_localCharacteristicInfo[i];

    if (localCharacteristicInfo->characteristic == &characteristic) {
      if (characteristic.properties() & BLEBroadcast && localCharacteristicInfo->service) {
        unsigned char advData[31];
        unsigned char advDataLen = this->_advDataLen;

        // copy the existing advertisement data
        memcpy(advData, this->_advData, advDataLen);

        advDataLen += (4 + characteristic.valueLength());

        if (advDataLen <= 31) {
          BLEUuid uuid = BLEUuid(localCharacteristicInfo->service->uuid());

          advData[this->_advDataLen + 0] = 3 + characteristic.valueLength();
          advData[this->_advDataLen + 1] = 0x16;

          memcpy(&advData[this->_advDataLen + 2], uuid.data(), 2);
          memcpy(&advData[this->_advDataLen + 4], characteristic.value(), characteristic.valueLength());

          sd_ble_gap_adv_data_set(advData, advDataLen, NULL, 0); // update advertisement data
          success = true;

          this->_broadcastCharacteristic = &characteristic;
        }
      }
      break;
    }
  }

  return success;
}

bool nRF51822::canNotifyCharacteristic(BLECharacteristic& /*characteristic*/) {
  return (this->_txBufferCount > 0);
}

bool nRF51822::canIndicateCharacteristic(BLECharacteristic& /*characteristic*/) {
  return (this->_txBufferCount > 0);
}

bool nRF51822::canReadRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      success = (this->_remoteCharacteristicInfo[i].valueHandle &&
                  this->_remoteCharacteristicInfo[i].properties.read &&
                  !this->_remoteRequestInProgress);
      break;
    }
  }

  return success;
}

bool nRF51822::readRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      if (this->_remoteCharacteristicInfo[i].valueHandle && this->_remoteCharacteristicInfo[i].properties.read) {
        this->_remoteRequestInProgress = true;
        success = (sd_ble_gattc_read(this->_connectionHandle, this->_remoteCharacteristicInfo[i].valueHandle, 0) == NRF_SUCCESS);
      }
      break;
    }
  }

  return success;
}

bool nRF51822::canWriteRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      if (this->_remoteCharacteristicInfo[i].valueHandle) {
        if (this->_remoteCharacteristicInfo[i].properties.write) {
          success = !this->_remoteRequestInProgress;
        } else if (this->_remoteCharacteristicInfo[i].properties.write_wo_resp) {
          success = (this->_txBufferCount > 0);
        }
      }
      break;
    }
  }

  return success;
}

bool nRF51822::writeRemoteCharacteristic(BLERemoteCharacteristic& characteristic, const unsigned char value[], unsigned char length) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      if (this->_remoteCharacteristicInfo[i].valueHandle &&
                  (this->_remoteCharacteristicInfo[i].properties.write_wo_resp || this->_remoteCharacteristicInfo[i].properties.write) &&
                  (this->_txBufferCount > 0)) {

        ble_gattc_write_params_t writeParams;

        writeParams.write_op = (this->_remoteCharacteristicInfo[i].properties.write) ? BLE_GATT_OP_WRITE_REQ : BLE_GATT_OP_WRITE_CMD;
#ifndef __RFduino__
        writeParams.flags = 0;
#endif
        writeParams.handle = this->_remoteCharacteristicInfo[i].valueHandle;
        writeParams.offset = 0;
        writeParams.len = length;
        writeParams.p_value = (uint8_t*)value;

        this->_remoteRequestInProgress = true;

        this->_txBufferCount--;

        success = (sd_ble_gattc_write(this->_connectionHandle, &writeParams) == NRF_SUCCESS);
      }
      break;
    }
  }

  return success;
}

bool nRF51822::canSubscribeRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      success = (this->_remoteCharacteristicInfo[i].valueHandle &&
                (this->_remoteCharacteristicInfo[i].properties.notify || this->_remoteCharacteristicInfo[i].properties.indicate));
      break;
    }
  }

  return success;
}

bool nRF51822::subscribeRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      if (this->_remoteCharacteristicInfo[i].valueHandle &&
                  (this->_remoteCharacteristicInfo[i].properties.notify || this->_remoteCharacteristicInfo[i].properties.indicate)) {

        ble_gattc_write_params_t writeParams;

        uint16_t value = (this->_remoteCharacteristicInfo[i].properties.notify ? 0x0001 : 0x002);

        writeParams.write_op = BLE_GATT_OP_WRITE_REQ;
#ifndef __RFduino__
        writeParams.flags = 0;
#endif
        writeParams.handle = (this->_remoteCharacteristicInfo[i].valueHandle + 1); // don't discover descriptors for now
        writeParams.offset = 0;
        writeParams.len = sizeof(value);
        writeParams.p_value = (uint8_t*)&value;

        this->_remoteRequestInProgress = true;

        success = (sd_ble_gattc_write(this->_connectionHandle, &writeParams) == NRF_SUCCESS);
      }
      break;
    }
  }

  return success;
}

bool nRF51822::canUnsubscribeRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  return this->canSubscribeRemoteCharacteristic(characteristic);
}

bool nRF51822::unsubcribeRemoteCharacteristic(BLERemoteCharacteristic& characteristic) {
  bool success = false;

  for (int i = 0; i < this->_numRemoteCharacteristics; i++) {
    if (this->_remoteCharacteristicInfo[i].characteristic == &characteristic) {
      if (this->_remoteCharacteristicInfo[i].valueHandle &&
                  (this->_remoteCharacteristicInfo[i].properties.notify || this->_remoteCharacteristicInfo[i].properties.indicate)) {

        ble_gattc_write_params_t writeParams;

        uint16_t value = 0x0000;

        writeParams.write_op = BLE_GATT_OP_WRITE_REQ;
#ifndef __RFduino__
        writeParams.flags = 0;
#endif
        writeParams.handle = (this->_remoteCharacteristicInfo[i].valueHandle + 1); // don't discover descriptors for now
        writeParams.offset = 0;
        writeParams.len = sizeof(value);
        writeParams.p_value = (uint8_t*)&value;

        this->_remoteRequestInProgress = true;

        success = (sd_ble_gattc_write(this->_connectionHandle, &writeParams) == NRF_SUCCESS);
      }
      break;
    }
  }

  return success;
}

#define KONSIN 1


#define BYPASS_DISABLED 	LOW
#define BYPASS_ENABLED 	    HIGH

#define RECV_DISABLED		LOW


bool nRF51822::ble_tx_power_activate(void)
{
	static uint8_t _high_enabled=0;
	int ret = true;
#if defined(PIN_FEM_TX_EN)

	if (_tx_Power >= HIGH_POWER_TX)
	{
		if (_high_enabled)
			return true;
		if (_adv_started)
			sd_ble_gap_adv_stop();
		pinMode(PIN_FEM_BYPASS,OUTPUT);
		digitalWrite(PIN_FEM_BYPASS,BYPASS_DISABLED);
		sd_ble_gap_tx_power_set(0);
		pa_lna_init(g_ADigitalPinMap[PIN_FEM_TX_EN],g_ADigitalPinMap[PIN_FEM_RX_EN]);
		if (_adv_started)
			this->startAdvertising();
		_high_enabled = 1;
	}
	else
	{
		pinMode(PIN_FEM_BYPASS,OUTPUT);
		pinMode(PIN_FEM_TX_EN,OUTPUT);
		pinMode(PIN_FEM_RX_EN,OUTPUT);
		digitalWrite(PIN_FEM_BYPASS,RECV_DISABLED);
#if KONSIN
		digitalWrite(PIN_FEM_TX_EN,LOW);
		digitalWrite(PIN_FEM_RX_EN,LOW);
#else
		digitalWrite(PIN_FEM_TX_EN,HIGH);
		digitalWrite(PIN_FEM_RX_EN,HIGH);
#endif
		ret = (sd_ble_gap_tx_power_set(_tx_Power) == NRF_SUCCESS);
		_high_enabled = 0;
		return (ret);
	}
#else
	ret = (sd_ble_gap_tx_power_set(_tx_Power) == NRF_SUCCESS);
	return (ret);
#endif


}

bool nRF51822::setTxPower(int txPower) {

  if (_adv_started && (txPower==_tx_Power))
	  return(true);

  if (txPower <= -40) {
    txPower = -40;
  } else if (txPower <= -30) {
    txPower = -30;
  } else if (txPower <= -20) {
    txPower = -20;
  } else if (txPower <= -16) {
    txPower = -16;
  } else if (txPower <= -12) {
    txPower = -12;
  } else if (txPower <= -8) {
    txPower = -8;
  } else if (txPower <= -4) {
    txPower = -4;
  } else if (txPower <= 0) {
    txPower = 0;
  } else if (txPower <= 4) {
    txPower = 4;
  } else {
#if defined(PIN_FEM_TX_EN)
    if (txPower>=HIGH_POWER_TX)
        txPower=HIGH_POWER_TX;
    else
        txPower=MAX_BLE_TX_POWER;
#else
	txPower = MAX_BLE_TX_POWER;
#endif
  }
  _tx_Power = txPower;
  if (_adv_started)
	   return (ble_tx_power_activate());
  return true;
}


bool nRF51822::startAdvertising() {

  ble_gap_adv_params_t advertisingParameters;

  memset(&advertisingParameters, 0x00, sizeof(advertisingParameters));

  advertisingParameters.type        = this->_connectable ? BLE_GAP_ADV_TYPE_ADV_IND : ( this->_hasScanData ? BLE_GAP_ADV_TYPE_ADV_SCAN_IND : BLE_GAP_ADV_TYPE_ADV_NONCONN_IND );
  advertisingParameters.p_peer_addr = NULL;
  advertisingParameters.fp          = BLE_GAP_ADV_FP_ANY;
//Brickcom
#if (NRF_SD_BLE_API_VERSION == 2)
  advertisingParameters.p_whitelist = NULL; //&m_whitelist;
#endif
  advertisingParameters.interval    = (this->_advertisingInterval * 16) / 10; // advertising interval (in units of 0.625 ms)
  advertisingParameters.timeout     = (this->_advertisingTimeout);

#ifdef NRF_51822_DEBUG
  //Serial.print(F("Start advertisement advertisingParameters.interval:"));
  //Serial.print(advertisingParameters.interval);
  //Serial.println();
  BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] Start advertisement advertising, Parameters.interval:%d(%dms)\n",advertisingParameters.interval,this->_advertisingInterval);
#endif

  _adv_started = 1;

  //Brickcom
#if (NRF_SD_BLE_API_VERSION == 2) // <4
  return (sd_ble_gap_adv_start(&advertisingParameters) == NRF_SUCCESS);
#else
#define APP_BLE_CONN_CFG_TAG            1                                 /**< A tag identifying the SoftDevice BLE configuration. */
  int ret = sd_ble_gap_adv_start(&advertisingParameters,APP_BLE_CONN_CFG_TAG); // == NRF_SUCCESS;
  //Serial.print("adv start : ");
  //Serial.print(ret==NRF_SUCCESS? "Success ":"Fail ");
  //Serial.println(ret);
#ifdef NRF_51822_DEBUG
  BRK_COLOR_LOG_DEBUG((ret==NRF_SUCCESS?BOLD_GREEN_PRINT:BOLD_RED_PRINT), "[ble] Advertisement started, %s\n",ret==NRF_SUCCESS? "Success ":"Fail ");
#endif
  return (ret);
#endif
}

void nRF51822::disconnect() {
  sd_ble_gap_disconnect(this->_connectionHandle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
}

void nRF51822::requestAddress() {
  ble_gap_addr_t gapAddress;

  // Get BLE address.
  #if (NRF_SD_BLE_API_VERSION == 2)
  	  sd_ble_gap_address_get(&gapAddress);
  #else
  	  sd_ble_gap_addr_get(&gapAddress);
  #endif

#ifdef NRF_51822_DEBUG
  //Serial.print("[ble] gap addr get:");
  //Serial.print(_gapAddress.addr[0],HEX);
  //Serial.print(_gapAddress.addr[1],HEX);
  //Serial.print(_gapAddress.addr[2],HEX);
  //Serial.print(_gapAddress.addr[3],HEX);
  //Serial.print(_gapAddress.addr[4],HEX);
  //Serial.println(_gapAddress.addr[5],HEX);

  BRK_COLOR_LOG_DEBUG(BOLD_WHITE_PRINT,"[ble] Gap addr get:%02X%02X%02X%02X%02X%02X\n",
		  _gapAddress.addr[5],_gapAddress.addr[4],_gapAddress.addr[3],
		  _gapAddress.addr[2],_gapAddress.addr[1],_gapAddress.addr[0]);

#endif

  if (this->_eventListener) {
    this->_eventListener->BLEDeviceAddressReceived(*this, gapAddress.addr);
  }
}

/* Brickcom addedd */
void nRF51822::setDevAddress(uint8_t type, uint8_t *addr) {
  _gapAddress.addr_type=type;
  memcpy(_gapAddress.addr,addr,BLE_GAP_ADDR_LEN);
  //sd_ble_gap_address_set(BLE_GAP_ADDR_CYCLE_MODE_NONE,&_gapAddress);
}



#ifdef __cplusplus
extern "C" {
#endif

float getChipTemperature() {
#ifndef __RFduino__
  int32_t rawTemperature = getRawChipTemperature();
  float temperature = rawTemperature / 4.0;
  return temperature;  
#else 
  return 0.0;
#endif
}

int32_t getRawChipTemperature() {
#ifndef __RFduino__
  int32_t rawTemperature = 0;
  sd_temp_get(&rawTemperature);
  return rawTemperature;  
#else 
  return 0.0;
#endif
}

#ifdef __cplusplus
}
#endif


void nRF51822::requestTemperature() {
#ifndef __RFduino__
  int32_t rawTemperature = 0;

  sd_temp_get(&rawTemperature);

  float temperature = rawTemperature / 4.0;

  if (this->_eventListener) {
    this->_eventListener->BLEDeviceTemperatureReceived(*this, temperature);
  }
#endif
}

void nRF51822::requestBatteryLevel() {
}

#endif



#endif
