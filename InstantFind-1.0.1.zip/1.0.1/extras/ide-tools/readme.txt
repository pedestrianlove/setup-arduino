nRF5FlashSoftDevice.jar is the compiled version of nRF5FlashSoftDevice.java

Install nRF5FlashSoftDevice.jar in

<ArduinoSketchDir>\tools\nRF5FlashSoftDevice\tool  dir  i.e.

<ArduinoSketchDir>\tools\nRF5FlashSoftDevice\tool\nRF5FlashSoftDevice.jar

and restart the IDE